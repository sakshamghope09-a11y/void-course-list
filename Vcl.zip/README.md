# VOID COURSE LIST — Course Catalogue Website

A dark + gold course catalogue website: hero section, live search, sorting,
category drawer, course cards, cart with Telegram checkout, FAQs, and
infinite scroll. Pure HTML/CSS/JS — no build step, no dependencies.

## Make it yours (2 files)

| File | What to edit |
|---|---|
| `data/config.js` | Brand name, tagline, headings, **your Telegram username**, category icons/colours |
| `data/courses.js` | Your courses — title, category, price, added date, optional rating |

> Only list courses you own or are authorised to sell.

## Deploy (free)

- **Vercel / Netlify:** drag the `course-site` folder into their dashboard,
  or connect a GitHub repo containing it. Done.
- **GitHub Pages:** push the folder to a repo → Settings → Pages → deploy.
- **Locally:** open `index.html` in a browser, or run
  `python3 -m http.server 8000` in this folder.

## How the Telegram checkout works

Every **Unlock** button and **Buy all on Telegram** button opens
`t.me/<your-username>?text=…` with the course enquiry pre-filled as a draft
message. The website itself never handles payments.
