/* ============================================================
   SITE CONFIG — edit this file to make the site yours
   ============================================================
   name        -> brand word shown in white   (e.g. "VOID")
   nameAccent  -> brand word shown in accent  (e.g. "COURSE")
   tagline     -> small caps line under the brand
   telegram    -> your Telegram username WITHOUT the @
   ============================================================ */

window.SITE_CONFIG = {
  name: "VOID",
  nameAccent: "COURSE LIST",
  tagline: "LEARN. GROW. ACHIEVE",
  eyebrow: "SINCE 2021 — LEARN. GROW. ACHIEVE.",
  heading: ["Find your next ", "skill."],   // [normal text, italic accent text]
  collection: "The VOID COURSE LIST collection",
  telegram: "voidx_exee",
  loaderText: "Opening your course collection…",
  footerLine: "SINCE 2021 · LEARN · GROW · ACHIEVE",
  cartMax: 15,

  /* Poster style per category: emoji icon + gradient shades
     (monochrome, to match the VOID COURSE LIST black & ivory logo) */
  categories: {
    "Coding & Tech":     { icon: "💻", c1: "#484848", c2: "#101010" },
    "Web Development":   { icon: "🌐", c1: "#3e464d", c2: "#0e1114" },
    "Data & AI":         { icon: "🤖", c1: "#443f50", c2: "#111016" },
    "Design":            { icon: "🎨", c1: "#50403f", c2: "#161010" },
    "Marketing":         { icon: "📣", c1: "#50473a", c2: "#161310" },
    "Business":          { icon: "💼", c1: "#3f4a41", c2: "#101510" },
    "Finance":           { icon: "📈", c1: "#3a4a46", c2: "#0f1514" },
    "Competitive Exams": { icon: "🎯", c1: "#4d3f3f", c2: "#151010" }
  }
};
