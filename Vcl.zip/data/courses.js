/* ============================================================
   COURSE CATALOGUE — this is the only file you need to edit
   to change what the website sells.
   ------------------------------------------------------------
   Each course:
     title : course name shown on the card
     cat   : must match a key in SITE_CONFIG.categories
     price : price in ₹ (number, no symbols)
     added : date added (used by "Recently added" sort)
     r     : (optional) rating score, e.g. 4.8
     rc    : (optional) review count shown next to the rating

   The newest 3 courses get an automatic "NEW" ribbon.
   Replace this demo list with courses you own or are
   authorised to sell.
   ============================================================ */

window.COURSES = [
  // — Coding & Tech —
  { title: "Python Bootcamp 1.0",            cat: "Coding & Tech",     price: 499, added: "2026-09-28", r: 4.8, rc: 1240 },
  { title: "Java Foundation Batch",          cat: "Coding & Tech",     price: 499, added: "2026-09-12", r: 4.7, rc: 860  },
  { title: "C++ Mastery (DSA)",              cat: "Coding & Tech",     price: 399, added: "2026-08-30" },
  { title: "Data Structures & Algorithms",   cat: "Coding & Tech",     price: 599, added: "2026-08-11", r: 4.9, rc: 2100 },
  { title: "Competitive Programming 2.0",    cat: "Coding & Tech",     price: 349, added: "2026-07-25" },
  { title: "SQL & Databases Crash Course",   cat: "Coding & Tech",     price: 299, added: "2026-06-30", r: 4.5, rc: 430  },
  { title: "Git & GitHub Essentials",        cat: "Coding & Tech",     price: 199, added: "2026-05-18" },
  { title: "System Design Basics",           cat: "Coding & Tech",     price: 649, added: "2026-04-02", r: 4.6, rc: 315  },

  // — Web Development —
  { title: "Full-Stack Web Dev (MERN)",      cat: "Web Development",   price: 799, added: "2026-09-20", r: 4.9, rc: 1875 },
  { title: "Frontend Pro (React)",           cat: "Web Development",   price: 699, added: "2026-09-01", r: 4.8, rc: 1420 },
  { title: "Backend with Node.js",           cat: "Web Development",   price: 649, added: "2026-07-14", r: 4.6, rc: 705  },
  { title: "UI to Code (HTML & CSS)",        cat: "Web Development",   price: 249, added: "2026-06-06" },
  { title: "WordPress Website Building",     cat: "Web Development",   price: 399, added: "2026-03-21", r: 4.3, rc: 289  },

  // — Data & AI —
  { title: "Generative AI & Prompt Craft",   cat: "Data & AI",         price: 599, added: "2026-09-25", r: 4.7, rc: 940  },
  { title: "Machine Learning Foundations",   cat: "Data & AI",         price: 799, added: "2026-08-19", r: 4.8, rc: 1105 },
  { title: "Data Analytics with Python",     cat: "Data & AI",         price: 699, added: "2026-07-02", r: 4.7, rc: 830  },
  { title: "Power BI Dashboards",            cat: "Data & AI",         price: 399, added: "2026-05-09", r: 4.4, rc: 352  },
  { title: "Excel for Data Analysis",        cat: "Data & AI",         price: 299, added: "2026-02-27" },

  // — Design —
  { title: "UI/UX Design Masterclass",       cat: "Design",            price: 699, added: "2026-09-15", r: 4.8, rc: 1290 },
  { title: "Figma from Zero",                cat: "Design",            price: 349, added: "2026-08-05", r: 4.6, rc: 610  },
  { title: "Graphic Design Basics",          cat: "Design",            price: 299, added: "2026-06-17" },
  { title: "Video Editing (Premiere Pro)",   cat: "Design",            price: 449, added: "2026-04-23", r: 4.5, rc: 402  },

  // — Marketing —
  { title: "Digital Marketing 360",          cat: "Marketing",         price: 799, added: "2026-09-08", r: 4.7, rc: 1560 },
  { title: "Instagram Growth & Content",     cat: "Marketing",         price: 399, added: "2026-08-24", r: 4.5, rc: 720  },
  { title: "Performance Ads (Meta & Google)",cat: "Marketing",         price: 499, added: "2026-07-08", r: 4.6, rc: 515  },
  { title: "SEO & Content Writing",          cat: "Marketing",         price: 349, added: "2026-05-27", r: 4.4, rc: 348  },

  // — Business —
  { title: "Product Management 101",         cat: "Business",          price: 699, added: "2026-09-03", r: 4.6, rc: 470  },
  { title: "Startup Essentials",             cat: "Business",          price: 599, added: "2026-07-19", r: 4.5, rc: 390  },
  { title: "Freelancing & Client Handling",  cat: "Business",          price: 349, added: "2026-06-11", r: 4.4, rc: 305  },
  { title: "Public Speaking & Communication",cat: "Business",          price: 299, added: "2026-03-30", r: 4.3, rc: 264  },

  // — Finance —
  { title: "Stock Market Basics",            cat: "Finance",           price: 499, added: "2026-08-15", r: 4.5, rc: 880  },
  { title: "Personal Finance & Mutual Funds",cat: "Finance",           price: 349, added: "2026-06-22", r: 4.6, rc: 545  },
  { title: "Tally & Accounting Pro",         cat: "Finance",           price: 399, added: "2026-04-14", r: 4.2, rc: 221  },

  // — Competitive Exams —
  { title: "UPSC Foundation Batch",          cat: "Competitive Exams", price: 999, added: "2026-09-18", r: 4.8, rc: 1310 },
  { title: "GATE CSE Crash Course",          cat: "Competitive Exams", price: 899, added: "2026-08-08", r: 4.7, rc: 760  },
  { title: "JEE Maths Booster",              cat: "Competitive Exams", price: 549, added: "2026-05-05", r: 4.5, rc: 438  }
];
