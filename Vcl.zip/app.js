/* ============================================================
   SKILLVAULT — catalogue app
   Sections: 1) pure core logic  2) DOM / UI
   ============================================================ */
(function () {
  'use strict';

  var cfg = (typeof window !== 'undefined' && window.SITE_CONFIG) || {};
  var COURSES = ((typeof window !== 'undefined' && window.COURSES) || []).map(function (c, i) {
    c.num = i + 1;                 // fixed catalogue number (#1, #2, …)
    c.id = c.title.toLowerCase();  // stable id for the cart
    return c;
  });
  var BRAND = [cfg.name || '', cfg.nameAccent || ''].join(' ').trim();
  var BATCH = 24;

  /* ---------------- 1) pure core (no DOM) ---------------- */

  function normalize(s) { return String(s == null ? '' : s).toLowerCase().trim(); }

  function matchesSearch(course, q) {
    q = normalize(q).replace(/^#/, '');
    if (!q) return true;
    return normalize(course.title).indexOf(q) !== -1 ||
           normalize(course.cat).indexOf(q) !== -1 ||
           String(course.num) === q;
  }

  function applySort(list, mode) {
    var out = list.slice();
    if (mode === 'az')    out.sort(function (a, b) { return a.title.localeCompare(b.title); });
    if (mode === 'price') out.sort(function (a, b) { return a.price - b.price; });
    if (mode === 'new')   out.sort(function (a, b) { return String(b.added).localeCompare(String(a.added)); });
    return out;
  }

  function getFiltered(courses, state) {
    return applySort(courses.filter(function (c) {
      if (state.cat && c.cat !== state.cat) return false;
      return matchesSearch(c, state.q);
    }), state.sort);
  }

  function formatINR(n) { return '₹' + Number(n).toLocaleString('en-IN'); }

  function telegramUrl(text) {
    return 'https://t.me/' + (cfg.telegram || '') + '?text=' + encodeURIComponent(text);
  }

  function unlockText(title) {
    return 'Hi, I want to unlock "' + title + '" from ' + BRAND +
           '. Please confirm the price, availability and payment details.';
  }

  function cartText(items) {
    var lines = items.map(function (c, i) {
      return (i + 1) + '. ' + c.title + ' — ' + formatINR(c.price);
    });
    var total = items.reduce(function (s, c) { return s + c.price; }, 0);
    return 'Hi, I want to unlock ' + items.length + ' course' + (items.length > 1 ? 's' : '') +
           ' from ' + BRAND + ':\n' + lines.join('\n') +
           '\nTotal: ' + formatINR(total) +
           '\nPlease confirm the price, availability and payment details.';
  }

  function newestIds(courses, n) {
    return courses.slice().sort(function (a, b) {
      return String(b.added).localeCompare(String(a.added));
    }).slice(0, n).map(function (c) { return c.id; });
  }

  if (typeof window !== 'undefined') {
    window.SITE_CORE = {
      normalize: normalize, matchesSearch: matchesSearch, applySort: applySort,
      getFiltered: getFiltered, formatINR: formatINR, telegramUrl: telegramUrl,
      unlockText: unlockText, cartText: cartText, newestIds: newestIds
    };
  }

  /* ---------------- 2) DOM / UI ---------------- */
  if (typeof document === 'undefined') return;

  var $ = function (id) { return document.getElementById(id); };
  var state = { q: '', cat: null, sort: 'default', shown: BATCH };
  var NEW_IDS = newestIds(COURSES, 3);
  var cart = [];
  var toastTimer = null;

  /* --- apply config --- */
  document.title = BRAND + ' — Find your next skill';
  var brandHTML = (cfg.name || '') + ' <b>' + (cfg.nameAccent || '') + '</b>';
  $('loader-brand').innerHTML = brandHTML;
  $('loader-text').textContent = cfg.loaderText || 'Opening your course collection…';
  $('brand-name').innerHTML = brandHTML + '<small>' + (cfg.tagline || '') + '</small>';
  $('footer-brand').innerHTML = brandHTML + '<small>' + (cfg.footerLine || '') + '</small>';
  $('footer-name').textContent = BRAND;
  $('hero-eyebrow').textContent = cfg.eyebrow || '';
  var h = cfg.heading || ['Find your next ', 'skill.'];
  $('hero-heading').innerHTML = h[0] + '<em>' + h[1] + '</em>';
  $('hero-collection').textContent = cfg.collection || '';
  $('year').textContent = new Date().getFullYear();
  var tgHref = 'https://t.me/' + (cfg.telegram || '');
  Array.prototype.forEach.call(document.querySelectorAll('.tg-href'), function (a) { a.href = tgHref; });
  $('tg-link').href = tgHref;
  $('empty-request').href = tgHref;

  /* --- loader --- */
  function hideLoader() { $('loader').classList.add('done'); }
  window.addEventListener('load', function () { setTimeout(hideLoader, 650); });
  setTimeout(hideLoader, 2500); // safety net

  /* --- toast --- */
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }

  /* --- cart helpers --- */
  function saveCart() {
    try { localStorage.setItem('voidcourse_cart', JSON.stringify(cart)); } catch (e) {}
  }
  function loadCart() {
    try { cart = JSON.parse(localStorage.getItem('voidcourse_cart')) || []; } catch (e) { cart = []; }
    var valid = {};
    COURSES.forEach(function (c) { valid[c.id] = true; });
    cart = cart.filter(function (id) { return valid[id]; });
  }
  function inCart(id) { return cart.indexOf(id) !== -1; }
  function cartCourses() {
    return cart.map(function (id) {
      for (var i = 0; i < COURSES.length; i++) if (COURSES[i].id === id) return COURSES[i];
      return null;
    }).filter(Boolean);
  }
  function cartAdd(id, title) {
    if (inCart(id)) return;
    if (cart.length >= (cfg.cartMax || 15)) { toast('Cart is full (max ' + (cfg.cartMax || 15) + ' courses)'); return; }
    cart.push(id); saveCart(); updateCartUI(); syncCartButtons();
    $('cart-count').classList.remove('bump'); void $('cart-count').offsetWidth; $('cart-count').classList.add('bump');
    toast('Added "' + title + '" to cart');
  }
  function cartRemove(id) {
    cart = cart.filter(function (x) { return x !== id; });
    saveCart(); updateCartUI(); syncCartButtons();
  }
  function cartTotal() {
    return cartCourses().reduce(function (s, c) { return s + c.price; }, 0);
  }

  /* --- card rendering --- */
  function catMeta(cat) {
    return (cfg.categories && cfg.categories[cat]) || { icon: '📚', c1: '#4c6ef5', c2: '#161633' };
  }
  function cardHTML(c) {
    var m = catMeta(c.cat);
    var isNew = NEW_IDS.indexOf(c.id) !== -1;
    var rating = (c.r && c.rc)
      ? '<div class="rating"><svg><use href="#i-star"/></svg>' + c.r.toFixed(1) +
        ' <small>(' + (c.rc >= 1000 ? (c.rc / 1000).toFixed(1) + 'k' : c.rc) + ' reviews)</small></div>'
      : '';
    var inC = inCart(c.id);
    return '<article class="card" data-id="' + c.id.replace(/"/g, '&quot;') + '">' +
      '<div class="poster" style="--c1:' + m.c1 + ';--c2:' + m.c2 + '">' +
        '<span class="price">' + formatINR(c.price) + '</span>' +
        '<span class="cat-chip">' + c.cat + '</span>' +
        '<div class="poster-icon" aria-hidden="true">' + m.icon + '</div>' +
        (isNew ? '<span class="new-chip">★ NEW</span>' : '') +
      '</div>' +
      '<div class="card-body">' +
        '<div class="card-meta"><span class="cat">' + c.cat + '</span><span class="num">#' + c.num + '</span></div>' +
        '<h3>' + c.title + '</h3>' + rating +
        '<div class="actions">' +
          '<a class="buy" target="_blank" rel="noopener noreferrer" href="' +
            telegramUrl(unlockText(c.title)) + '">' +
            '<svg><use href="#i-unlock"/></svg>Unlock · ' + formatINR(c.price) + '</a>' +
          '<button class="cart-add' + (inC ? ' added' : '') + '" aria-label="Add ' + c.title + ' to cart">' +
            (inC ? '✓ Added' : '+ Cart') + '</button>' +
        '</div>' +
      '</div>' +
    '</article>';
  }

  function currentList() { return getFiltered(COURSES, state); }

  function render() {
    var list = currentList();
    var shown = list.slice(0, state.shown);
    $('grid').innerHTML = shown.map(cardHTML).join('');
    $('empty').hidden = list.length > 0;
    $('grid').style.display = list.length ? '' : 'none';
    $('result-count').innerHTML = '<b>' + list.length + '</b> course' + (list.length === 1 ? '' : 's') + ' to explore';
    $('shown-count').textContent = list.length
      ? 'Showing ' + shown.length + ' of ' + list.length
      : '';
    var allShown = shown.length >= list.length;
    $('scroll-spinner').classList.toggle('on', !allShown && list.length > 0);
    $('active-category').innerHTML = (state.cat || 'All Courses') + ' <span>⌄</span>';
  }

  function syncCartButtons() {
    Array.prototype.forEach.call(document.querySelectorAll('.card'), function (card) {
      var btn = card.querySelector('.cart-add');
      var inC = inCart(card.getAttribute('data-id'));
      btn.classList.toggle('added', inC);
      btn.textContent = inC ? '✓ Added' : '+ Cart';
    });
  }

  /* --- cart UI --- */
  function updateCartUI() {
    var items = cartCourses();
    var total = cartTotal();
    $('cart-count').textContent = items.length;
    $('sticky-count').textContent = items.length + ' course' + (items.length === 1 ? '' : 's');
    $('sticky-total').textContent = formatINR(total);
    $('sticky-cart').hidden = items.length === 0;

    $('cart-items').innerHTML = items.length
      ? items.map(function (c) {
          var m = catMeta(c.cat);
          return '<div class="cart-item">' +
            '<div class="mini" style="--c1:' + m.c1 + ';--c2:' + m.c2 + '">' + m.icon + '</div>' +
            '<div class="info"><strong>' + c.title + '</strong><small>' + c.cat + ' · #' + c.num + '</small></div>' +
            '<b style="color:var(--gold);font-size:13px">' + formatINR(c.price) + '</b>' +
            '<button class="rm" data-id="' + c.id.replace(/"/g, '&quot;') + '" aria-label="Remove ' + c.title + '">✕</button>' +
          '</div>';
        }).join('')
      : '<p style="color:var(--muted);font-size:13px;text-align:center;padding:18px 0">Your cart is empty. Tap <b>+ Cart</b> on any course.</p>';

    $('cart-total').innerHTML = items.length
      ? 'Estimated total <span>' + formatINR(total) + '</span>'
      : '';

    var url = items.length ? telegramUrl(cartText(items)) : tgHref;
    $('checkout').href = url;
    $('sticky-checkout').href = url;
  }

  /* --- category drawer --- */
  function buildCategories() {
    var counts = {};
    COURSES.forEach(function (c) { counts[c.cat] = (counts[c.cat] || 0) + 1; });
    var html = '<button class="cat-btn' + (state.cat ? '' : ' active') + '" data-cat="">' +
      '<span class="cicon">🗂️</span><span class="all">All Courses<small>' + COURSES.length + ' courses</small></span></button>';
    Object.keys(cfg.categories || {}).forEach(function (name) {
      if (!counts[name]) return;
      html += '<button class="cat-btn' + (state.cat === name ? ' active' : '') + '" data-cat="' + name + '">' +
        '<span class="cicon">' + cfg.categories[name].icon + '</span>' +
        '<span>' + name + '<small>' + counts[name] + ' course' + (counts[name] === 1 ? '' : 's') + '</small></span></button>';
    });
    $('categories').innerHTML = html;
  }

  function setCategory(cat) {
    state.cat = cat || null;
    state.shown = BATCH;
    buildCategories(); render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function resetAll(msg) {
    state = { q: '', cat: null, sort: 'default', shown: BATCH };
    $('search').value = ''; $('sort').value = 'default';
    buildCategories(); render();
    if (msg) toast(msg);
  }

  /* --- events --- */
  var searchTimer = null;
  $('search').addEventListener('input', function () {
    clearTimeout(searchTimer);
    var v = this.value;
    searchTimer = setTimeout(function () {
      state.q = v; state.shown = BATCH; render();
    }, 140);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && document.activeElement !== $('search') &&
        !/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement.tagName)) {
      e.preventDefault(); $('search').focus();
    }
  });
  $('sort').addEventListener('change', function () {
    state.sort = this.value; state.shown = BATCH; render();
  });
  $('grid').addEventListener('click', function (e) {
    var btn = e.target.closest('.cart-add');
    if (!btn) return;
    var card = btn.closest('.card');
    var id = card.getAttribute('data-id');
    var title = card.querySelector('h3').textContent;
    if (inCart(id)) { cartRemove(id); toast('Removed "' + title + '"'); }
    else cartAdd(id, title);
  });
  $('cart-items').addEventListener('click', function (e) {
    var rm = e.target.closest('.rm');
    if (rm) cartRemove(rm.getAttribute('data-id'));
  });
  $('cart-open').addEventListener('click', function () { updateCartUI(); $('cart-dialog').showModal(); });
  $('view-cart').addEventListener('click', function () { updateCartUI(); $('cart-dialog').showModal(); });
  $('close-cart').addEventListener('click', function () { $('cart-dialog').close(); });
  $('clear-cart').addEventListener('click', function () {
    cart = []; saveCart(); updateCartUI(); syncCartButtons(); toast('Cart cleared');
  });
  $('open-categories').addEventListener('click', function () { buildCategories(); $('category-dialog').showModal(); });
  $('active-category').addEventListener('click', function () { buildCategories(); $('category-dialog').showModal(); });
  $('close-categories').addEventListener('click', function () { $('category-dialog').close(); });
  $('categories').addEventListener('click', function (e) {
    var btn = e.target.closest('.cat-btn');
    if (!btn) return;
    $('category-dialog').close();
    setCategory(btn.getAttribute('data-cat'));
  });
  $('reset').addEventListener('click', function () {
    $('category-dialog').close();
    resetAll('Filters reset');
  });
  $('clear-search').addEventListener('click', function () { resetAll(); });
  $('refresh').addEventListener('click', function () {
    resetAll('Catalogue refreshed');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  Array.prototype.forEach.call(document.querySelectorAll('.faq-trigger'), function (b) {
    b.addEventListener('click', function () { $('faq-dialog').showModal(); });
  });
  $('close-faq').addEventListener('click', function () { $('faq-dialog').close(); });
  $('collapse-faq').addEventListener('click', function () {
    Array.prototype.forEach.call(document.querySelectorAll('#faq-dialog details'), function (d) { d.open = false; });
  });

  /* --- infinite scroll --- */
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      if (!entries[0].isIntersecting) return;
      var list = currentList();
      if (state.shown < list.length) {
        state.shown += BATCH;
        render();
      }
    }, { rootMargin: '600px' }).observe($('scroll-sentinel'));
  }

  /* --- init --- */
  loadCart();
  buildCategories();
  render();
  updateCartUI();
})();
