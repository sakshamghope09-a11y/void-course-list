/* Generated from voidx.config.json by scripts/sync-brand.mjs — do not edit by hand.
   To rebrand: edit voidx.config.json, then run `npm run brand`. */
window.ZC_BRAND = {
  "_readme": "EDIT THIS FILE TO REBRAND THE SITE, then run: npm run brand   —  nothing else hard-codes the brand.",
  "name": "VOID",
  "nameStrong": "COURSE",
  "fullName": "VOID COURSE",
  "tagline": "LEARN • GROW • ACHIEVE",
  "since": "2021",
  "telegram": "voidx_exee",
  "siteUrl": "https://void-course.vercel.app",
  "heroTitle": "Find your next",
  "heroAccent": "skill.",
  "heroLede": "An open archive of {total} recorded courses across coding, design, trading, marketing and more. Browse freely — no account, no fees.",
  "searchPlaceholder": "Search a course, a creator, a category or #number…",
  "enquiry": "Hi! I found {course} in the {brand} archive. Could you share the access details and availability?",
  "listIntro": "Hi! I picked these courses from the {brand} archive:",
  "listOutro": "Could you share the access details and availability for this list?",
  "maxList": 15,
  "messageBudget": 3500
};
