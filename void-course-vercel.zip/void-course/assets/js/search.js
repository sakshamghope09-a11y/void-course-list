/* ============================================================================
   search.js — query parsing, incremental index, relevance scoring
   ----------------------------------------------------------------------------
   The legacy search was `(title + category).toLowerCase().includes(query)`
   plus an exact `#id` match. That fails on the three things people actually
   type into a 3,695-item catalogue:
     "sigma 12 dsa"      → multiple words in any order
     "amit goel options" → creator + topic
     "dsa cours"         → prefix + typo
   So: tokenise, require every token (AND), score by field and by match quality,
   and fold in a domain alias table so "nifty" finds "Stock Market & Trading".
   ========================================================================== */
'use strict';

(function (ZC) {
  const { normalize, CATEGORY_ALIASES } = ZC.core;

  /* ── Query parsing ─────────────────────────────────────────────────────── */
  /**
   * @returns {{terms:string[], phrases:string[], id:number|null, raw:string, empty:boolean}}
   */
  function parseQuery(raw) {
    const text = String(raw || '').trim();
    const phrases = [];
    // Quoted phrases match literally.
    const withoutPhrases = text.replace(/"([^"]{2,})"/g, (_, p) => { phrases.push(normalize(p)); return ' '; });

    const idMatch = withoutPhrases.match(/(?:^|\s)#(\d{1,6})(?:\s|$)/) || withoutPhrases.match(/^#?(\d{1,6})$/);
    const id = idMatch ? Number(idMatch[1]) : null;

    const remainder = withoutPhrases.replace(/(?:^|\s)#\d{1,6}(?=\s|$)/, ' ').replace(/^\d{1,6}$/, ' ');
    const terms = normalize(remainder).split(' ').filter((t) => t.length > 0);

    return { terms, phrases, id, raw: text, empty: !terms.length && !phrases.length && id === null };
  }

  /* ── Index: extended incrementally as shards arrive ─────────────────────── */
  /* `built` is the high-water mark of indexed rows. Rows past it are handled by
     the substring fallback, so search is correct at every moment — including the
     first 100 ms while shard 0 is still being sliced. (The first version of this
     file built the index against an empty array and silently returned zero
     results for every query; keep the high-water mark explicit.) */
  const index = { ready: false, built: 0, progress: 0, titleTokens: [], titleNorm: [], creatorNorm: [], catNorm: [] };
  let building = false;
  let pending = false;

  function buildIndex(records, onProgress) {
    if (building) { pending = true; return; }        // coalesce rapid shard arrivals
    const from = index.built;
    const total = records.length;
    if (total <= from) { markReadyIfCaughtUp(total); return; }

    building = true;
    ZC.core.timeSlicedLoop(
      total - from,
      (k) => {
        const i = from + k;
        const c = records[i];
        const titleNorm = normalize(c.title);
        index.titleNorm[i] = titleNorm;
        index.titleTokens[i] = titleNorm.split(' ').filter(Boolean);
        index.creatorNorm[i] = c.creatorName ? normalize(c.creatorName) : '';
        index.catNorm[i] = normalize(c.category);
      },
      () => {
        index.built = Math.max(index.built, total);
        building = false;
        markReadyIfCaughtUp(total);
        onProgress && onProgress(1);
        ZC.data.emit('indexed', { built: index.built, total });
        if (pending) { pending = false; buildIndex(ZC.data.all, onProgress); }
      },
      6
    );
  }

  function markReadyIfCaughtUp(total) {
    const state = ZC.data && ZC.data.state;
    index.ready = index.built >= total && (state === 'ready' || state === 'partial');
  }

  /** Correct-but-simple matcher for rows the token index has not reached yet. */
  function fallbackScore(course, parsed) {
    const haystack = normalize(`${course.title} ${course.category} ${course.creatorName || ''}`);
    const title = normalize(course.title);
    if (parsed.id !== null && course.id !== parsed.id) return -1;
    let score = parsed.id !== null ? 100 : 0;
    for (const term of [...parsed.terms, ...parsed.phrases]) {
      if (!haystack.includes(term)) return -1;
      score += title.includes(term) ? SCORE.substring : SCORE.category;
    }
    return score;
  }

  /* ── Fuzzy helper: does `word` sit within one edit of `token`? ─────────── */
  function withinOneEdit(word, token) {
    const diff = word.length - token.length;
    if (diff > 1 || diff < -1) return false;
    let i = 0, j = 0, edits = 0;
    while (i < word.length && j < token.length) {
      if (word[i] === token[j]) { i++; j++; continue; }
      if (++edits > 1) return false;
      if (diff === 0) { i++; j++; }        // substitution
      else if (diff > 0) i++;              // extra char in the query word
      else j++;                            // missing char in the query word
    }
    return edits + (word.length - i) + (token.length - j) <= 1;
  }

  /* ── Scoring ───────────────────────────────────────────────────────────── */
  const SCORE = { exact: 14, prefix: 9, substring: 6, creator: 8, category: 5, alias: 4, fuzzy: 3, phrase: 12 };

  /** @returns {number} relevance (higher is better) or -1 when the course is rejected. */
  function scoreRow(i, course, parsed) {
    let score = 0;

    /* Course number: "#142" pins exactly one record. */
    if (parsed.id !== null) {
      if (course.id !== parsed.id) return -1;
      score += 100;
    }

    const title = index.titleNorm[i] || '';
    const tokens = index.titleTokens[i] || [];
    const creator = index.creatorNorm[i] || '';
    const cat = index.catNorm[i] || '';

    for (const term of parsed.terms) {
      let hit = 0;

      if (tokens.includes(term)) hit = SCORE.exact;
      else if (tokens.some((t) => t.startsWith(term))) hit = SCORE.prefix;
      else if (title.includes(term)) hit = SCORE.substring;

      if (!hit && creator && creator.includes(term)) hit = SCORE.creator;

      if (!hit) {
        if (cat.includes(term)) hit = SCORE.category;
        else {
          const alias = CATEGORY_ALIASES[term];
          if (alias && cat === alias) hit = SCORE.alias;
        }
      }

      // Typo tolerance only for words long enough that an edit is unambiguous.
      if (!hit && term.length >= 5) {
        const fuzzy = tokens.find((t) => withinOneEdit(term, t));
        if (fuzzy) hit = SCORE.fuzzy;
      }

      if (!hit) return -1; // every term must match something (AND semantics)
      score += hit;
    }

    for (const phrase of parsed.phrases) {
      if (!title.includes(phrase)) return -1;
      score += SCORE.phrase;
    }

    // Tie-breakers: a shorter, tighter title is the better answer for the same
    // score; stable by id so pagination and sorting never jitter.
    score += Math.max(0, 6 - Math.floor(course.title.length / 18));
    return score;
  }

  /**
   * Filter + order a candidate list.
   * @param {Array} records  decoded courses (already category/sort-filtered if desired)
   * @param {object} parsed  output of parseQuery
   * @param {string} sort    'relevance' | 'new' | 'az' | 'za' | 'price' | 'number'
   */
  function run(records, parsed, sort) {
    const scored = [];
    for (let i = 0; i < records.length; i++) {
      const course = records[i];
      if (parsed.empty) { scored.push([0, course]); continue; }
      // Indexed rows get full scoring; not-yet-indexed rows get the fallback.
      const s = course.__i < index.built ? scoreRow(course.__i, course, parsed) : fallbackScore(course, parsed);
      if (s >= 0) scored.push([s, course]);
    }

    const cmp = comparators(parsed)[sort] || comparators(parsed).relevance;
    scored.sort((a, b) => cmp(a, b) || a[1].id - b[1].id);
    return scored.map((pair) => pair[1]);
  }

  function comparators(parsed) {
    const relevance = (a, b) => (b[0] - a[0]) || (a[1].id - b[1].id);
    if (parsed.empty) relevance(0, 0); // keep signature symmetrical
    return {
      relevance,
      new: (a, b) => (b[1].ts || 0) - (a[1].ts || 0) || b[1].id - a[1].id,
      az: (a, b) => a[1].title.localeCompare(b[1].title, 'en', { sensitivity: 'base' }),
      za: (a, b) => b[1].title.localeCompare(a[1].title, 'en', { sensitivity: 'base' }),
      creator: (a, b) => (a[1].creatorName || '\uffff').localeCompare(b[1].creatorName || '\uffff', 'en', { sensitivity: 'base' }) || a[1].id - b[1].id,
      number: (a, b) => b[1].id - a[1].id,
    };
  }

  ZC.search = { parseQuery, buildIndex, run, index, withinOneEdit };
})(window.ZC);
