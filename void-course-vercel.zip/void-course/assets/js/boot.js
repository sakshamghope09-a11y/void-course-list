/* boot.js — created first so the generated data files have somewhere to write.
   Kept as a file (not inline script) so the deploy can ship a strict CSP with no
   'unsafe-inline'. Also carries the flag the static course pages set. */
window.ZC = { data: { meta: null, rows: [] }, pages: window.ZC?.pages || { ready: false } };
