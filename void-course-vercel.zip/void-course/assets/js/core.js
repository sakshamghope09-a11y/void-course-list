/* ============================================================================
   VOID COURSE — runtime core (brand, helpers, storage, telemetry)
   ----------------------------------------------------------------------------
   Brand values arrive from assets/js/brand.js, which is generated from
   voidx.config.json by `npm run brand`. The literals below are only a safety
   net so the site still renders if that file is missing; edit the config, not
   this file, to rebrand.
   ========================================================================== */
'use strict';

window.ZC = window.ZC || {};

(function (ZC) {
  const DEFAULTS = {
    name: 'VOID', nameStrong: 'COURSE', fullName: 'VOID COURSE',
    tagline: 'LEARN • GROW • ACHIEVE', since: '2021',
    telegram: 'voidx_exee', siteUrl: 'https://void-course.vercel.app',
    heroTitle: 'Find your next', heroAccent: 'skill.',
    heroLede: 'An open archive of {total} recorded courses across coding, design, trading, marketing and more. Browse freely — no account, no fees.',
    searchPlaceholder: 'Search a course, a creator, a category or #number…',
    enquiry: 'Hi! I found {course} in the {brand} archive. Could you share the access details and availability?',
    listIntro: 'Hi! I picked these courses from the {brand} archive:',
    listOutro: 'Could you share the access details and availability for this list?',
    maxList: 15, messageBudget: 3500, telegramBase: 'https://t.me/',
  };

  const BRAND = Object.assign({}, DEFAULTS, window.ZC_BRAND || {});
  BRAND.telegram = String(BRAND.telegram).replace(/^@/, '');
  BRAND.telegramBase = BRAND.telegramBase || 'https://t.me/';

  /* Message templates support {course} / {brand} so the config stays readable. */
  const fill = (template, vars) => String(template).replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null ? vars[k] : m));
  BRAND.enquiryFor = (subject) => fill(BRAND.enquiry, { course: subject, brand: BRAND.fullName });
  BRAND.listIntroText = () => fill(BRAND.listIntro, { brand: BRAND.fullName });
  BRAND.listOutroText = () => fill(BRAND.listOutro, { brand: BRAND.fullName });

  /* Keep the document title/description in step even if the page head is stale. */
  if (typeof document !== 'undefined') document.documentElement.dataset.brand = BRAND.fullName;

  ZC.BRAND = BRAND;

  /* ── Text safety ───────────────────────────────────────────────────────── */
  const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const esc = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (c) => ESCAPES[c]);

  /** Strip diacritics/punctuation and collapse whitespace — the search alphabet. */
  function normalize(text) {
    return String(text)
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9#+]+/g, ' ')
      .trim()
      .replace(/\s+/g, ' ');
  }

  /* ── Formatting ────────────────────────────────────────────────────────── */
  const inr = new Intl.NumberFormat('en-IN');
  const count = (n) => inr.format(n);
  const plural = (n, one, many) => `${count(n)} ${n === 1 ? one : many || one + 's'}`;
  /** Courses are free to browse, so there is no currency formatting any more. */
  const priceLabel = () => 'Open access';

  /* ── Telegram deep links ───────────────────────────────────────────────── */
  function telegram(text) {
    const base = BRAND.telegramBase + BRAND.telegram;
    return text ? `${base}?text=${encodeURIComponent(text)}` : base;
  }
  const telegramUrlLength = (text) => telegram(text).length;
  const enquiryFor = (course) => telegram(BRAND.enquiryFor(`${course.title} (#${course.id})`));

  /* ── Scheduling ────────────────────────────────────────────────────────── */
  function debounce(fn, wait) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  /** Run work between frames so long tasks never block input. */
  function idleRun(fn) {
    if (typeof requestIdleCallback === 'function') return requestIdleCallback(fn, { timeout: 500 });
    return requestAnimationFrame(() => fn({ timeRemaining: () => 8 }));
  }

  /** Chunked loop: processes `each(i)` until the time budget per frame is spent. */
  function timeSlicedLoop(total, each, done, budgetMs = 6) {
    let i = 0;
    const step = (deadline) => {
      const until = performance.now() + Math.min(budgetMs, deadline?.timeRemaining?.() ?? budgetMs);
      while (i < total && performance.now() < until) { each(i); i++; }
      if (i < total) idleRun(step);
      else done && done();
    };
    idleRun(step);
  }

  /* ── Versioned storage (never throws, migrates old keys) ───────────────── */
  const store = {
    available: (() => {
      try { localStorage.setItem('zc.probe', '1'); localStorage.removeItem('zc.probe'); return true; }
      catch { return false; }
    })(),
    get(key, fallback) {
      if (!this.available) return fallback;
      try {
        const raw = localStorage.getItem(key);
        return raw == null ? fallback : JSON.parse(raw);
      } catch { return fallback; }
    },
    set(key, value) {
      if (!this.available) return false;
      try { localStorage.setItem(key, JSON.stringify(value)); return true; }
      catch { return false; }
    },
    remove(key) { try { localStorage.removeItem(key); } catch { /* ignore */ } },
    /** Migrate `old` → `key` once, so a rebuild never drops a visitor's list. */
    migrate(key, old) {
      const existing = this.get(key, null);
      if (existing) return existing;
      const legacy = this.get(old, null);
      if (legacy) { this.set(key, legacy); this.remove(old); }
      return legacy;
    },
  };

  /* ── Toast + screen-reader channel ─────────────────────────────────────── */
  let toastTimer;
  function toast(message) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
  }
  function announce(message) {
    const el = document.getElementById('live');
    if (el) el.textContent = message;
  }

  /** Copy helper: clipboard API where available, legacy textarea otherwise. */
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:-1000px';
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch { ok = false; }
      ta.remove();
      return ok;
    }
  }

  /* ── Analytics: cookieless, buffered, fully inert until wired ──────────── */
  const analytics = (() => {
    const buffer = [];
    const ENDPOINT = window.ZC_ANALYTICS_ENDPOINT || null; // set this to enable
    return {
      track(event, props = {}) {
        buffer.push({ event, props, t: Date.now() });
        if (buffer.length > 300) buffer.shift();
        if (ENDPOINT && navigator.sendBeacon) {
          try { navigator.sendBeacon(ENDPOINT, JSON.stringify([buffer.pop()])); } catch { /* ignore */ }
        }
      },
      /** Debug hook: ZC.core.analytics.dump() in the console. */
      dump: () => buffer.slice(),
    };
  })();

  /* ── Category search aliases (domain vocabulary → catalogue vocabulary) ── */
  const CATEGORY_ALIASES = {
    dsa: 'coding & tech', algo: 'coding & tech', algorithm: 'coding & tech', coding: 'coding & tech',
    dev: 'coding & tech', developer: 'coding & tech', programming: 'coding & tech', react: 'coding & tech',
    web: 'coding & tech', python: 'coding & tech', java: 'coding & tech', cpp: 'coding & tech',
    stock: 'stock market & trading', share: 'stock market & trading', trading: 'stock market & trading',
    nifty: 'stock market & trading', options: 'stock market & trading', intraday: 'stock market & trading',
    astro: 'astrology & occult', kundli: 'astrology & occult', jyotish: 'astrology & occult',
    horoscope: 'astrology & occult', numerology: 'astrology & occult', tarot: 'astrology & occult',
    vastu: 'astrology & occult', reiki: 'astrology & occult', healing: 'astrology & occult',
    marketing: 'digital marketing & ads', seo: 'digital marketing & ads', ads: 'digital marketing & ads',
    meta: 'digital marketing & ads', google: 'digital marketing & ads', facebook: 'digital marketing & ads',
    ai: 'ai & automation', ml: 'ai & automation', chatgpt: 'ai & automation', automation: 'ai & automation',
    prompt: 'ai & automation', n8n: 'ai & automation',
    design: 'graphic design & arts', photoshop: 'graphic design & arts', canva: 'graphic design & arts',
    illustrator: 'graphic design & arts',
    edit: 'video editing & media', editing: 'video editing & media', premiere: 'video editing & media',
    reels: 'video editing & media', vfx: 'video editing & media',
    gym: 'fitness & health', yoga: 'fitness & health', weight: 'fitness & health', diet: 'fitness & health',
    nutrition: 'fitness & health',
    business: 'business & sales', sales: 'business & sales', startup: 'business & sales',
    ecommerce: 'e-commerce & dropshipping', dropship: 'e-commerce & dropshipping', shopify: 'e-commerce & dropshipping',
    tax: 'finance & taxation', gst: 'finance & taxation', itr: 'finance & taxation', accounting: 'finance & taxation',
    money: 'personal growth & mindset', mindset: 'personal growth & mindset', productivity: 'personal growth & mindset',
    hacking: 'cyber security & hacking', ethical: 'cyber security & hacking', bug: 'cyber security & hacking',
    language: 'communication & languages', english: 'communication & languages', spoken: 'communication & languages',
    dating: 'dating & relationships', relationship: 'dating & relationships', marriage: 'dating & relationships',
    fashion: 'fashion & boutique', boutique: 'fashion & boutique', tailoring: 'fashion & boutique',
  };

  ZC.core = {
    esc, normalize, count, plural, priceLabel,
    telegram, telegramUrlLength, enquiryFor,
    debounce, idleRun, timeSlicedLoop, store, toast, announce, copyText, analytics,
    CATEGORY_ALIASES,
  };
})(window.ZC);
