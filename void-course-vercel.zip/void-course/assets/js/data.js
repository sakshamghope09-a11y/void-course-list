/* ============================================================================
   data.js — progressive archive loader
   ----------------------------------------------------------------------------
   Why shards instead of one 687 KB file:
     • the first screen paints after ~15 KB (shard 0) instead of ~114 KB
     • the rest streams in while the visitor reads, so search covers the whole
       catalogue within a few hundred ms of load
     • a failure is recoverable per shard instead of blanking the whole app
   Shards are plain <script> files that push into window.ZC.data.rows. That keeps
   the app working from file://, from any static host, and inside sandboxed
   previews where fetch()/modules are blocked.
   ========================================================================== */
'use strict';

(function (ZC) {
  const core = ZC.core;

  const data = (ZC.data = ZC.data || {});
  data.meta = data.meta || null;
  data.rows = data.rows || [];       // raw arrays pushed by shard files
  data.all = [];                     // decoded course objects
  data.byId = new Map();
  data.state = 'idle';               // idle | loading | ready | partial | error
  data.loadedShards = new Set();

  const listeners = new Map();
  function on(event, fn) {
    const bucket = listeners.get(event);
    if (bucket) bucket.push(fn); else listeners.set(event, [fn]);
    return () => {
      const list = listeners.get(event) || [];
      const i = list.indexOf(fn);
      if (i > -1) list.splice(i, 1);
    };
  }
  function emit(event, payload) {
    const bucket = listeners.get(event);
    if (bucket) for (const fn of bucket.slice()) fn(payload);
  }

  const IMAGE_CDN = (data.meta && data.meta.imageCdn) || 'https://i.ibb.co/';
  /** Owners' ratings file is optional and may be absent, null or a legacy const. */
  function ratingsTable() {
    const table = (typeof window.COURSE_RATINGS === 'object' && window.COURSE_RATINGS) || {};
    return table;
  }

  const creators = () => (data.meta && data.meta.creators) || [];

  /** Decode a wire row into the object the UI uses.
      Columns: [id, title, catIndex, imageRef, addedAtMs, creatorIndex]. */
  function decode(row) {
    const [id, title, catIndex, imageRef, ts, creatorIndex] = row;
    const c = {
      id,
      title,
      category: (data.meta.categories[catIndex] || {}).name || 'Uncategorised',
      image: imageRef ? (imageRef.startsWith('http') ? imageRef : IMAGE_CDN + imageRef) : './public/mark.png',
      ts: ts || null,
      creatorName: creatorIndex == null ? null : creators()[creatorIndex] || null,
      rating: null,
    };
    const r = ratingsTable()[id];
    if (r && Number.isFinite(r.score) && r.score >= 1 && r.score <= 5 && Number.isSafeInteger(r.count) && r.count > 0) {
      c.rating = r;
    }
    return c;
  }

  /* Row → object decoding is cursor based and cheap (3,695 rows ≈ 8 ms), so it
     runs inline per arriving shard; the expensive part (the search index) is the
     time-sliced one. A cursor keeps appended rows in id order across shards. */
  let decodeCursor = 0;
  function drainDecodeQueue() {
    const start = decodeCursor;
    for (; decodeCursor < data.rows.length; decodeCursor++) {
      const c = decode(data.rows[decodeCursor]);
      c.__i = decodeCursor;
      data.all.push(c);
      data.byId.set(c.id, c);
    }
    if (decodeCursor !== start) emit('changed', { added: decodeCursor - start });
  }

  /* ── Shard transport ───────────────────────────────────────────────────── */
  const shardEls = new Map();
  function loadShard(name, attempt = 0) {
    return new Promise((resolve) => {
      const version = data.cacheBuster ? `?v=${data.cacheBuster}` : '';
      const el = document.createElement('script');
      el.src = `./data/${name}${version}`;
      el.async = true;
      el.onload = () => { shardEls.set(name, el); resolve(true); };
      el.onerror = () => {
        el.remove();
        if (attempt < 2) {
          // Exponential-ish backoff, then give up on this shard only.
          setTimeout(() => loadShard(name, attempt + 1).then(resolve), 600 * (attempt + 1));
        } else {
          emit('shard-error', { name });
          resolve(false);
        }
      };
      document.head.appendChild(el);
    });
  }

  /** Kick off loading inside a minimum-delay promise so tests can await it. */
  function boot() {
    if (data.state === 'loading' || data.state === 'ready') return data.ready || Promise.resolve();
    data.state = 'loading';
    emit('state', data.state);

    const shards = (data.meta && data.meta.shards) || [];
    if (!shards.length) {
      data.state = 'error';
      emit('state', data.state);
      emit('error', { reason: 'no-manifest' });
      return Promise.resolve(false);
    }

    // Shard 0 first (it is <link rel=preload>ed), the rest in parallel.
    const first = loadShard(shards[0].file);
    const rest = shards.slice(1).map((s) => loadShard(s.file));

    data.ready = first
      .then((ok) => {
        if (!ok) {
          data.state = 'error';
          emit('state', data.state);
          emit('error', { reason: 'shard-0-failed' });
          return false;
        }
        drainDecodeQueue();
        ZC.search.buildIndex(data.all, () => emit('index-progress', ZC.search.index.progress));
        emit('progress', { loaded: 1, total: shards.length });
        return Promise.all(rest).then((results) => {
          drainDecodeQueue();
          ZC.search.buildIndex(data.all, () => emit('index-progress', ZC.search.index.progress));
          const failed = results.filter((r) => !r).length;
          data.state = failed ? 'partial' : 'ready';
          emit('progress', { loaded: shards.length - failed, total: shards.length });
          emit('state', data.state);
          if (failed) emit('error', { reason: 'shards-failed', failed });
          return true;
        });
      });

    return data.ready;
  }

  /** Re-download the catalogue, bypassing HTTP caches (the legacy refresh button
      called location.reload(), which could serve the same stale bytes back). */
  function reload() {
    data.cacheBuster = Date.now();
    data.rows.length = 0;
    data.all.length = 0;
    data.byId.clear();
    data.loadedShards.clear();
    decodeCursor = 0;
    ZC.search.index.ready = false;
    ZC.search.index.built = 0;
    ZC.search.index.titleNorm.length = 0;
    ZC.search.index.titleTokens.length = 0;
    ZC.search.index.creatorNorm.length = 0;
    ZC.search.index.catNorm.length = 0;
    data.state = 'idle';
    data.ready = null;
    return boot();
  }

  /* ── Queries ───────────────────────────────────────────────────────────── */
  const categoryCounts = () => {
    const map = new Map();
    for (const c of data.all) map.set(c.category, (map.get(c.category) || 0) + 1);
    return map;
  };

  Object.assign(data, { on, emit, boot, reload, decode, categoryCounts });

  /* Getters must be defined, not Object.assign-ed: Object.assign *invokes* a
     getter and copies the resulting value, which froze `loaded` at 0 (it ran
     before any shard had decoded) and permanently hid the empty state. */
  Object.defineProperties(data, {
    total: { get: () => (data.meta ? data.meta.total : 0), configurable: true },
    /** Courses whose data has arrived so far (useful while shards stream in). */
    loaded: { get: () => data.all.length, configurable: true },
    /** True once every shard has decoded, i.e. counts can be trusted. */
    complete: { get: () => data.all.length >= (data.meta ? data.meta.total : 0), configurable: true },
  });
})(window.ZC);
