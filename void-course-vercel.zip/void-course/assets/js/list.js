/* ============================================================================
   list.js — "saved courses" list
   ----------------------------------------------------------------------------
   This fork does not sell anything, so the old cart no longer totals money. What
   is still genuinely useful is exactly what the reference site did well: let a
   visitor shortlist courses while browsing and hand the whole list to the owner
   in one Telegram message. The list:
     • persists in versioned localStorage, and migrates an older key if present
     • caps at 15 courses / ~3,500 characters so the Telegram URL never overflows
     • can be copied to the clipboard for anyone who prefers to paste it manually
   ========================================================================== */
'use strict';

(function (ZC) {
  const { store, esc, telegram, telegramUrlLength, toast, copyText, analytics } = ZC.core;
  const BRAND = ZC.BRAND;
  const KEY = 'void.list.v1';
  const LEGACY_KEYS = ['zc.cart.v3', 'zc-cart'];

  let ids = [];

  /* ── Persistence ───────────────────────────────────────────────────────── */
  function restore() {
    let saved = store.get(KEY, null);
    if (!Array.isArray(saved)) {
      for (const legacy of LEGACY_KEYS) {
        const older = store.get(legacy, null);
        if (Array.isArray(older) && older.length) { saved = older; store.set(KEY, saved); store.remove(legacy); break; }
      }
    }
    ids = Array.isArray(saved) ? saved.filter((id) => Number.isSafeInteger(id)).slice(0, BRAND.maxList) : [];
  }

  function persist() {
    store.set(KEY, ids);
    render();
  }

  /* ── Message building ──────────────────────────────────────────────────── */
  function message(list = ids) {
    const lines = list.map((id, i) => {
      const c = ZC.data.byId.get(id);
      return c ? `${i + 1}. ${c.title} (#${c.id})` : null;
    }).filter(Boolean);
    return `${BRAND.listIntroText()}\n\n${lines.join('\n')}\n\n${BRAND.listOutroText()}`;
  }

  /** Plain-text list for the clipboard (no greeting, just the shortlist). */
  function plainList(list = ids) {
    return list.map((id, i) => {
      const c = ZC.data.byId.get(id);
      return c ? `${i + 1}. ${c.title} — #${c.id}` : null;
    }).filter(Boolean).join('\n');
  }

  function fits(id) {
    if (ids.includes(id)) return { ok: true };
    if (ids.length >= BRAND.maxList) {
      return { ok: false, message: `A list holds ${BRAND.maxList} courses — send this one on Telegram first.` };
    }
    if (telegramUrlLength(message([...ids, id])) > BRAND.messageBudget) {
      return { ok: false, message: 'This enquiry is already long — send it on Telegram, then start a fresh list.' };
    }
    return { ok: true };
  }

  /* ── Mutations ─────────────────────────────────────────────────────────── */
  function add(id) {
    const check = fits(id);
    if (!check.ok) { toast(check.message); return false; }
    ids = [...ids, id];
    persist();
    toast('Saved to your list');
    analytics.track('list_add', { id, size: ids.length });
    return true;
  }

  function remove(id) {
    ids = ids.filter((x) => x !== id);
    persist();
    analytics.track('list_remove', { id, size: ids.length });
  }

  function toggle(id) {
    if (ids.includes(id)) { remove(id); toast('Removed from your list'); }
    else add(id);
  }

  function clear() {
    if (!ids.length) return;
    ids = [];
    persist();
    toast('List cleared');
    analytics.track('list_clear');
  }

  /* ── Rendering ─────────────────────────────────────────────────────────── */
  function render() {
    const countEl = document.getElementById('save-count');
    if (!countEl) return;

    countEl.textContent = String(ids.length);
    countEl.dataset.empty = String(ids.length === 0);
    document.querySelector('.save-trigger')?.setAttribute('aria-label', `Open saved list, ${ids.length} courses`);

    const items = ids.map((id) => ZC.data.byId.get(id)).filter(Boolean);
    const rows = document.getElementById('list-items');
    if (rows) {
      rows.innerHTML = items.length
        ? items.map((c) => `<div class="list-row">
            <div><strong>${esc(c.title)}</strong><small>#${c.id} · ${esc(c.category)}</small></div>
            <button data-remove="${c.id}" aria-label="Remove ${esc(c.title)} from your list">×</button>
          </div>`).join('')
        : `<p class="label list-empty">Nothing saved yet — tap <b>Save</b> on any course.</p>`;
    }

    const href = telegram(message());
    const checkout = document.getElementById('list-send');
    if (checkout) { checkout.href = href; checkout.hidden = !items.length; }
    const copyBtn = document.getElementById('list-copy');
    if (copyBtn) copyBtn.hidden = !items.length;
    const clearBtn = document.getElementById('list-clear');
    if (clearBtn) clearBtn.hidden = !items.length;

    const sticky = document.getElementById('sticky-list');
    if (sticky) {
      sticky.hidden = ids.length === 0;
      const count = document.getElementById('sticky-count');
      const hint = document.getElementById('sticky-hint');
      const send = document.getElementById('sticky-send');
      if (count) count.textContent = `${ZC.core.plural(ids.length, 'course')} saved`;
      if (hint) hint.textContent = 'Send the shortlist to Telegram, or copy it';
      if (send) send.href = href;
    }
    document.body.classList.toggle('list-active', ids.length > 0);
    ZC.render.refreshSaveButtons();
  }

  /* ── Wiring ────────────────────────────────────────────────────────────── */
  function init() {
    restore();

    document.getElementById('list-items')?.addEventListener('click', (event) => {
      const btn = event.target.closest('[data-remove]');
      if (btn) remove(Number(btn.dataset.remove));
    });
    document.getElementById('list-clear')?.addEventListener('click', clear);

    document.getElementById('list-copy')?.addEventListener('click', async () => {
      const ok = await copyText(plainList());
      toast(ok ? 'List copied — paste it anywhere' : 'Copy failed — long-press to select the list');
      if (ok) analytics.track('list_copy', { size: ids.length });
    });

    ZC.data.on('changed', render);
    ZC.data.on('state', render);
    render();
  }

  ZC.list = {
    init, render, add, remove, toggle, clear,
    has: (id) => ids.includes(id),
    get ids() { return ids.slice(); },
    get size() { return ids.length; },
    get limit() { return BRAND.maxList; },
    message, plainList, fits,
  };
})(window.ZC);
