/* ============================================================================
   render.js — windowed (virtualised) poster grid for VOID COURSE
   ----------------------------------------------------------------------------
   Only the rows inside the viewport (plus one row of overscan) exist in the DOM,
   so scrolling a 3,695-item archive costs the same as scrolling twelve items.
   Absolute rows are laid out on a row height measured once per column count.

   Poster handling matters more here than in most catalogues: the upstream
   posters arrive at wildly different aspect ratios, so every cover is a fixed
   208 px tall box with `object-fit: cover`. The grid therefore never reflows
   (zero layout shift) and every card is the same height — which is exactly what
   makes the virtual window exact instead of a guess. A toolbar toggle switches
   the whole grid to `contain` for visitors who want the full poster artwork.
   ========================================================================== */
'use strict';

(function (ZC) {
  const { esc, telegram, enquiryFor } = ZC.core;
  const BRAND = ZC.BRAND;

  const FALLBACK_ROW_H = 420;
  const OVERSCAN_ROWS = 2;
  const FULL_RENDER_LIMIT = 48; // below this, skip virtualisation entirely

  const state = {
    grid: null,
    cards: [],
    cols: 3,
    rowH: 0,
    measuredCardH: 0,
    measuredFor: 0,
    measuredWidth: 0,
    rows: 0,
    virtual: false,
    minRows: 0,
    mounted: new Map(),
    pool: [],
    ticking: false,
    lastFirstRow: -1,
    fitArtwork: false,
  };

  /* Inline placeholder — a blocked or broken poster must not cost a request. */
  const PLACEHOLDER =
    'data:image/svg+xml;utf8,' +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 190">
        <rect width="320" height="190" fill="#0e0e12"/>
        <g fill="none" stroke="#6d6b66" stroke-width="1.4">
          <path d="M8 182 V8 H312 V182 Z" stroke-opacity=".35"/>
          <path d="M116 116 L146 84 L176 116 L200 96 L228 116" />
          <circle cx="122" cy="66" r="9"/>
        </g>
        <text x="160" y="152" fill="#6d6b66" font-family="sans-serif" font-size="11" letter-spacing="2" text-anchor="middle">POSTER UNAVAILABLE</text>
      </svg>`
    );

  const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;

  /** Deep link target: the static course page when it has been generated,
      otherwise the in-page dialog. Both paths are correct at any moment. */
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  /** "Added Nov 2025" — only when the record carries a plausible timestamp. */
  function addedStamp(ts) {
    if (!ts || typeof ts !== 'number') return 'Recorded course';
    const d = new Date(ts);
    if (Number.isNaN(d.getTime()) || d.getFullYear() < 2015 || d.getFullYear() > 2100) return 'Recorded course';
    return `Added ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
  }

  const courseHref = (id) => (window.ZC.pages && window.ZC.pages.ready ? `./course/${id}.html` : `?course=${id}`);

  function ratingHTML(course) {
    const r = course.rating;
    if (!r) return '';
    return `<span class="rating" aria-label="Rated ${r.score.toFixed(1)} out of 5 from ${r.count} reviews">` +
      `${icon('star')}<strong>${r.score.toFixed(1)}</strong><span class="n">(${ZC.core.count(r.count)})</span></span>`;
  }

  function cardHTML(course, saved, aboveFold = false) {
    const imgAttrs = aboveFold ? 'loading="eager" fetchpriority="high"' : 'loading="lazy"';
    /* Two-line-safe byline: the creator when we know one, otherwise the month
       the course entered the archive — never filler like "Course archive" on
       every untagged card. */
    const byline = course.creatorName
      ? `by <button data-filter-creator="${esc(course.creatorName)}">${esc(course.creatorName)}</button>`
      : `<span class="stamp">${esc(addedStamp(course.ts))}</span>`;
    const rating = ratingHTML(course);

    return `<article class="card" role="listitem" data-course="${course.id}" data-saved="${saved ? 'true' : 'false'}">
  <div class="cover">
    <img src="${esc(course.image)}" alt="${esc(course.title)} — poster" ${imgAttrs} decoding="async"
         referrerpolicy="no-referrer" width="640" height="400" data-fallback="${PLACEHOLDER}">
    <div class="cover-top">
      <button class="badge-cat" data-filter-category="${esc(course.category)}" title="Show all ${esc(course.category)} courses">${esc(course.category)}</button>
      <button class="badge-num" data-copy-link="${course.id}" title="Copy a link to this course" aria-label="Copy a link to course ${course.id}: ${esc(course.title)}">#${course.id}</button>
    </div>
  </div>
  <div class="card-body">
    <h3><a href="${courseHref(course.id)}" data-open-course="${course.id}" title="${esc(course.title)}">${esc(course.title)}</a></h3>
    <div class="card-by">${byline}</div>
    ${rating ? `<div>${rating}</div>` : ''}
    <div class="card-actions">
      <a class="ask" href="${enquiryFor(course)}" target="_blank" rel="noopener noreferrer"
         aria-label="Ask about ${esc(course.title)} on Telegram">${icon('telegram')}<span>Get access</span></a>
      <button class="save" data-save="${course.id}" aria-pressed="${saved ? 'true' : 'false'}"
              aria-label="${saved ? 'Remove' : 'Save'} ${esc(course.title)} ${saved ? 'from' : 'to'} your list"
              title="${saved ? 'Remove from list' : 'Save to list'}">${icon('bookmark')}<span>${saved ? 'Saved' : 'Save'}</span></button>
    </div>
  </div>
</article>`;
  }

  function skeletonRow() {
    const card = `<div class="skeleton-card"><div class="sk-cover sk-shimmer"></div>
      <div class="sk-line sk-shimmer"></div><div class="sk-line sk-shimmer"></div><div class="sk-line sk-shimmer"></div></div>`;
    return `<div class="row">${card.repeat(3)}</div>`;
  }

  /* ── Geometry ──────────────────────────────────────────────────────────── */
  function columnCount() {
    const template = getComputedStyle(state.grid).gridTemplateColumns;
    const cols = template && template !== 'none' ? template.trim().split(/\s+/).filter(Boolean).length : 0;
    if (cols > 0) return cols;
    const w = state.grid.clientWidth;
    return w >= 1000 ? 3 : w >= 640 ? 2 : 1;
  }

  /** Measure a real card in a hidden probe, cached per column count. */
  function measureCardHeight(cols) {
    if (state.measuredFor === cols && state.measuredCardH) return state.measuredCardH;
    const probe = document.createElement('div');
    probe.className = 'row';
    probe.setAttribute('aria-hidden', 'true');
    probe.style.cssText = 'position:absolute;top:0;left:0;right:0;visibility:hidden;pointer-events:none;z-index:-1';
    const sample = state.cards[0];
    probe.innerHTML = sample ? cardHTML(sample, false) : skeletonRow();
    state.grid.appendChild(probe);
    const card = probe.querySelector('.card') || probe.querySelector('.skeleton-card');
    const h = card ? Math.round(card.getBoundingClientRect().height) : 0;
    probe.remove();
    state.measuredFor = cols;
    state.measuredCardH = h > 200 ? h : FALLBACK_ROW_H;
    return state.measuredCardH;
  }

  function gapPx() {
    const g = parseFloat(getComputedStyle(state.grid).getPropertyValue('--gap'));
    return Number.isFinite(g) ? g : 22;
  }

  /* ── Window calculation + mounting ─────────────────────────────────────── */
  function paint() {
    state.ticking = false;
    const { grid } = state;
    if (!state.cards.length) { clearRows(); return; }

    const rowH = state.rowH;
    const gridTop = grid.getBoundingClientRect().top + window.scrollY;
    const viewTop = window.scrollY - gridTop;
    const viewBottom = viewTop + window.innerHeight;

    const first = Math.max(0, Math.floor(viewTop / rowH) - OVERSCAN_ROWS);
    const last = Math.min(state.rows - 1, Math.ceil(viewBottom / rowH) + OVERSCAN_ROWS);
    const firstRow = Math.min(first, Math.max(0, state.rows - 1 - (last - first)));

    if (state.virtual && firstRow === state.lastFirstRow) return;
    state.lastFirstRow = firstRow;

    /* Two ways rows stay mounted:
       • the visible window, always;
       • everything above the "Show next" watermark, so a keyboard or screen-reader
         visitor who reveals rows without scrolling never has them removed. */
    const keepFrom = state.minRows > 0 && firstRow <= state.minRows ? 0 : firstRow;
    const keepTo = Math.max(last, state.minRows);

    for (const [index, el] of state.mounted) {
      if (index < keepFrom || index > keepTo) {
        el.remove();
        state.mounted.delete(index);
        if (state.pool.length < 40) state.pool.push(el);
      }
    }

    let appended = false;
    for (let r = keepFrom; r <= keepTo; r++) {
      if (state.mounted.has(r)) continue;
      const el = state.pool.pop() || document.createElement('div');
      el.className = 'row';
      el.dataset.row = String(r);
      el.style.top = `${r * rowH}px`;
      const from = r * state.cols;
      const slice = state.cards.slice(from, from + state.cols);
      el.innerHTML = slice.map((c) => cardHTML(c, ZC.list.has(c.id), r === 0)).join('');
      state.mounted.set(r, el);
      grid.appendChild(el);
      appended = true;
    }
    if (appended) reorderRows();
  }

  /** Keep DOM order == visual order so Tab and screen readers walk the grid. */
  function reorderRows() {
    const ordered = [...state.mounted.entries()].sort((a, b) => a[0] - b[0]).map(([, el]) => el);
    for (const el of ordered) state.grid.appendChild(el);
  }

  function clearRows() {
    const pool = [];
    for (const el of state.grid.querySelectorAll('.row')) {
      if (el.getAttribute('aria-hidden') === 'true') continue;
      el.remove();
      if (pool.length < 40) pool.push(el);
    }
    state.mounted.clear();
    state.pool = pool;
    state.lastFirstRow = -1;
  }

  const schedulePaint = () => {
    if (state.ticking) return;
    state.ticking = true;
    requestAnimationFrame(paint);
  };

  /* ── Public API ────────────────────────────────────────────────────────── */
  function setCards(cards) {
    state.cards = cards;
    state.virtual = cards.length > FULL_RENDER_LIMIT;
    state.minRows = 0;
    state.grid.dataset.virtual = String(state.virtual);
    state.cols = columnCount();
    state.grid.style.setProperty('--cols', String(state.cols));
    state.rowH = measureCardHeight(state.cols) + gapPx();
    state.rows = Math.ceil(cards.length / state.cols);
    state.lastFirstRow = -1;
    clearRows();

    if (!state.virtual) {
      state.grid.style.height = '';
      const html = [];
      for (let r = 0; r < state.rows; r++) {
        const slice = cards.slice(r * state.cols, r * state.cols + state.cols);
        html.push(`<div class="row">${slice.map((c) => cardHTML(c, ZC.list.has(c.id))).join('')}</div>`);
      }
      state.grid.innerHTML = html.join('');
      return;
    }

    state.grid.style.height = `${state.rows * state.rowH - gapPx()}px`;
    paint();
  }

  /** Repaint only the save buttons after a list change — never the whole window. */
  function refreshSaveButtons() {
    if (!state.grid) return;
    for (const el of state.grid.querySelectorAll('[data-save]')) {
      const id = Number(el.dataset.save);
      const saved = ZC.list.has(id);
      el.setAttribute('aria-pressed', String(saved));
      el.setAttribute('aria-label', `${saved ? 'Remove' : 'Save'} course ${id} ${saved ? 'from' : 'to'} your list`);
      el.title = saved ? 'Remove from list' : 'Save to list';
      el.innerHTML = `${icon('bookmark')}<span>${saved ? 'Saved' : 'Save'}</span>`;
      const card = el.closest('.card');
      if (card) card.dataset.saved = String(saved);
    }
  }

  /** Reveal more rows for keyboard / assistive-tech users who do not scroll. */
  function showNextRows(step = 4) {
    state.minRows = Math.min(state.rows - 1, state.minRows + step);
    state.lastFirstRow = -1;
    paint();
    return (state.minRows + 1) * state.cols;
  }

  /** Toolbar toggle: letterbox the artwork instead of filling the cover box. */
  function setArtworkFit(fit) {
    state.fitArtwork = !!fit;
    if (state.grid) state.grid.dataset.fit = String(state.fitArtwork);
  }

  function sameHead(cards) {
    if (!state.grid || state.virtual === false) return false;
    const visibleRows = Math.max(1, state.mounted.size || 0);
    const head = state.cards.slice(0, visibleRows * state.cols).map((c) => c.id).join(',');
    const next = cards.slice(0, visibleRows * state.cols).map((c) => c.id).join(',');
    return head === next && next.length > 0;
  }

  function init({ grid }) {
    state.grid = grid;
    grid.innerHTML = skeletonRow().repeat(3);
    grid.setAttribute('aria-busy', 'true');
    state.fitArtwork = ZC.core.store.get('void.fit', false);
    setArtworkFit(state.fitArtwork);

    window.addEventListener('scroll', schedulePaint, { passive: true });
    window.addEventListener('resize', ZC.core.debounce(() => {
      const cols = columnCount();
      const widthChanged = Math.abs(window.innerWidth - (state.measuredWidth || 0)) > 24;
      if (cols !== state.cols || widthChanged) {
        state.measuredWidth = window.innerWidth;
        if (state.cards.length) setCards(state.cards);
        return;
      }
      state.lastFirstRow = -1;
      paint();
    }, 140), { passive: true });

    if ('ResizeObserver' in window) {
      new ResizeObserver(ZC.core.debounce(() => {
        const cols = columnCount();
        if (cols !== state.cols && state.cards.length) setCards(state.cards);
      }, 180)).observe(grid.parentElement);
    }

    /* Poster failures degrade to an inline placeholder and are counted, so the
       owner can see which uploads are dead without leaving the page. */
    grid.addEventListener('error', (event) => {
      const img = event.target;
      if (!(img instanceof HTMLImageElement) || img.dataset.failed) return;
      img.dataset.failed = 'true';
      img.src = img.dataset.fallback || PLACEHOLDER;
      ZC.core.analytics.track('poster_error', { id: img.closest('.card')?.dataset.course });
    }, true);
  }

  ZC.render = {
    init, setCards, paint: schedulePaint, refreshSaveButtons, showNextRows,
    setArtworkFit, sameHead, cardHTML, skeletonRow, state,
    get fitArtwork() { return state.fitArtwork; },
  };
})(window.ZC);
