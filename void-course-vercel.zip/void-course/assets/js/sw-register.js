/* sw-register.js — registers the offline shell.
   Kept as a file rather than an inline <script> so the deployment can ship a
   strict Content-Security-Policy with no 'unsafe-inline'. Only runs on a real
   origin: a file:// preview must never fight a stale service-worker cache. */
(function () {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'https:') return;
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./sw.js').catch(function () {
      /* Offline mode is a bonus — never let it block the page. */
    });
  });
})();
