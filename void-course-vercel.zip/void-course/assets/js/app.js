/* ============================================================================
   app.js — bootstrap, filtering, URL state, dialogs
   ----------------------------------------------------------------------------
   Every visible string, the Telegram handle and the brand name come from
   ZC.BRAND (assets/js/core.js). This file only wires behaviour, so rebranding
   never means hunting through markup.
   ========================================================================== */
'use strict';

(function (ZC) {
  const core = ZC.core;
  const BRAND = ZC.BRAND;

  const state = {
    q: '', cat: '', creator: '', sort: 'relevance', course: null,
    lastSignature: '', lastResults: [],
  };

  const els = {};
  const cache = (id) => (els[id] = els[id] || document.getElementById(id));

  /* Splash handling: it exists to make the first paint feel intentional, not to
     hide a slow load — so it is dismissed on the first rendered batch and, no
     matter what happens, removed after 3.5 s. */
  let splashDismissed = false;
  function dismissSplash() {
    if (splashDismissed) return;
    splashDismissed = true;
    const splash = cache('splash');
    if (!splash) return;
    splash.classList.add('is-gone');
    setTimeout(() => splash.remove(), 460);
  }

  /* ── Brand injection ───────────────────────────────────────────────────── */
  function paintBrand() {
    const set = (id, text) => { const el = cache(id); if (el) el.textContent = text; };
    set('brand-sub', BRAND.tagline);
    set('foot-since', BRAND.tagline);

    const heroLabel = cache('hero-label');
    if (heroLabel) heroLabel.textContent = BRAND.tagline;

    const title = cache('hero-title');
    if (title) title.innerHTML = `${core.esc(BRAND.heroTitle)} <em>${core.esc(BRAND.heroAccent)}</em>`;

    const lede = cache('hero-lede');
    if (lede) lede.innerHTML = core.esc(BRAND.heroLede).replace('{total}', `<b>${core.count(ZC.data.total)}</b>`);

    const search = cache('search');
    if (search) search.placeholder = BRAND.searchPlaceholder;

    const tg = cache('telegram-link');
    if (tg) {
      tg.href = core.telegram();
      tg.setAttribute('aria-label', `Message ${BRAND.fullName} on Telegram as @${BRAND.telegram}`);
    }
    set('year', String(new Date().getFullYear()));
    document.title = `${BRAND.fullName} — Find your next skill`;
  }

  /* ── URL <-> state ─────────────────────────────────────────────────────── */
  function readUrl() {
    const params = new URLSearchParams(location.search);
    state.q = params.get('q') || '';
    state.cat = params.get('cat') || '';
    state.creator = params.get('creator') || '';
    state.sort = params.get('sort') || 'relevance';
    const course = Number(params.get('course'));
    state.course = Number.isSafeInteger(course) && course > 0 ? course : null;
  }

  function writeUrl({ push = false } = {}) {
    const params = new URLSearchParams();
    if (state.q) params.set('q', state.q);
    if (state.cat) params.set('cat', state.cat);
    if (state.creator) params.set('creator', state.creator);
    if (state.sort && state.sort !== 'relevance') params.set('sort', state.sort);
    if (state.course) params.set('course', String(state.course));
    const next = `${location.pathname}${params.toString() ? '?' + params : ''}`;
    if (next === location.pathname + location.search) return;
    history[push ? 'pushState' : 'replaceState']({}, '', next);
  }

  /* ── Filtering pipeline ────────────────────────────────────────────────── */
  function candidates() {
    const all = ZC.data.all;
    if (!state.cat && !state.creator) return all;
    return all.filter((c) =>
      (!state.cat || c.category === state.cat) &&
      (!state.creator || c.creatorName === state.creator));
  }

  function currentResults() {
    const parsed = ZC.search.parseQuery(state.q);

    // A bare number means "that course number" first, but still falls back to text.
    if (parsed.id !== null && parsed.terms.length === 0 && parsed.phrases.length === 0) {
      const exact = ZC.data.byId.get(parsed.id);
      if (exact && (!state.cat || exact.category === state.cat)) return [exact];
    }

    const pool = candidates();
    if (parsed.empty) {
      const list = pool.slice();
      const cmp = {
        new: (a, b) => (b.ts || 0) - (a.ts || 0) || b.id - a.id,
        az: (a, b) => a.title.localeCompare(b.title, 'en', { sensitivity: 'base' }),
        za: (a, b) => b.title.localeCompare(a.title, 'en', { sensitivity: 'base' }),
        creator: (a, b) => (a.creatorName || '\uffff').localeCompare(b.creatorName || '\uffff', 'en', { sensitivity: 'base' }) || a.id - b.id,
        number: (a, b) => b.id - a.id,
        relevance: (a, b) => a.id - b.id,
      }[state.sort];
      list.sort(cmp || ((a, b) => a.id - b.id));
      return list;
    }
    return ZC.search.run(pool, parsed, state.sort);
  }

  function apply({ scroll = false, announce = true } = {}) {
    if (!ZC.data.loaded) return;
    const results = currentResults();
    const signature = `${results.length}:${results[0]?.id || 0}:${results[results.length - 1]?.id || 0}:${state.sort}:${state.cat}:${state.creator}:${ZC.data.loaded}`;

    state.lastResults = results;
    if (signature !== state.lastSignature) {
      state.lastSignature = signature;
      if (!ZC.render.sameHead(results)) ZC.render.setCards(results);
    }
    paintMeta(results);

    if (scroll) {
      const top = cache('grid').getBoundingClientRect().top + window.scrollY - 96;
      window.scrollTo({ top: Math.max(0, top), behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    }
    if (announce) {
      core.announce(results.length === 0
        ? 'No courses matched your search.'
        : `${core.plural(results.length, 'course')} match. Scroll to browse.`);
    }
    writeUrl();
  }

  const applyDebounced = core.debounce(() => apply(), 80);

  /* ── Meta UI ───────────────────────────────────────────────────────────── */
  function paintMeta(results) {
    const filtered = Boolean(state.q || state.cat || state.creator);
    const countEl = cache('result-count');
    if (countEl) {
      const loadedNote = ZC.data.state === 'loading' || ZC.data.state === 'partial'
        ? ` · searching ${core.count(ZC.data.loaded)} loaded so far` : '';
      countEl.innerHTML = filtered
        ? `<b>${core.plural(results.length, 'course')}</b> found${loadedNote}`
        : `<b>${core.plural(ZC.data.total, 'course')}</b> in the archive${loadedNote}`;
    }

    const empty = cache('empty');
    if (empty) empty.hidden = results.length !== 0 || !ZC.data.loaded;

    const showMore = cache('load-more');
    const shown = cache('shown-count');
    const virtual = ZC.render.state.virtual;
    const label = cache('category-label');
    if (label) label.textContent = state.cat || 'All categories';
    const listLabel = cache('list-label');
    if (listLabel) listLabel.textContent = ZC.list.size ? `Saved (${ZC.list.size})` : 'Saved list';

    if (showMore) {
      const revealed = ZC.render.state.cols * (ZC.render.state.minRows + 1);
      showMore.textContent = `Show next ${Math.min(ZC.render.state.cols * 4, Math.max(0, results.length - revealed))} courses`;
      showMore.hidden = !virtual || results.length <= revealed;
    }
    if (shown) {
      if (!results.length) shown.textContent = '';
      else if (!virtual) shown.textContent = `Showing all ${core.plural(results.length, 'course')}`;
      else {
        const mounted = Math.min(ZC.render.state.mounted.size * ZC.render.state.cols, results.length);
        shown.textContent = `Showing ${core.count(mounted)} of ${core.plural(results.length, 'course')} — keep scrolling, or use “Show next”.`;
      }
    }

    const chips = [];
    if (state.q) chips.push(['q', `Search: “${state.q}”`]);
    if (state.cat) chips.push(['cat', state.cat]);
    if (state.creator) chips.push(['creator', `by ${state.creator}`]);
    const holder = cache('active-filters');
    if (holder) {
      holder.innerHTML = chips.map(([key, text]) =>
        `<span class="chip">${core.esc(text)}<button data-clear-filter="${key}" aria-label="Remove filter ${core.esc(text)}"><svg aria-hidden="true"><use href="#i-close"/></svg></button></span>`).join('');
    }

    const tag = cache('build-tag');
    if (tag && ZC.data.meta) tag.textContent = `archive v${ZC.data.meta.version}`;
  }

  /* ── Categories + creators ─────────────────────────────────────────────── */
  function renderCategories() {
    const holder = cache('categories');
    if (!holder || !ZC.data.meta) return;
    const counts = ZC.data.categoryCounts();
    const rows = ZC.data.meta.categories
      .map((c) => ({ name: c.name, count: counts.get(c.name) ?? c.count }))
      .filter((c) => c.count > 0);
    holder.innerHTML = [
      `<button class="cat" data-category="" aria-pressed="${!state.cat}"><span>All categories</span><span class="n">${core.count(ZC.data.total)}</span></button>`,
      ...rows.map((c) => `<button class="cat" data-category="${core.esc(c.name)}" aria-pressed="${state.cat === c.name}">
        <span>${core.esc(c.name)}</span><span class="n">${core.count(c.count)}</span></button>`),
    ].join('');
  }

  function renderCreators() {
    const select = cache('creator-filter');
    if (!select || !ZC.data.meta) return;
    select.innerHTML = `<option value="">Anyone</option>` + ZC.data.meta.creators
      .map((name) => `<option value="${core.esc(name)}"${state.creator === name ? ' selected' : ''}>${core.esc(name)}</option>`)
      .join('');
  }

  /* ── Course dialog ─────────────────────────────────────────────────────── */
  function openCourse(id, { push = true } = {}) {
    const course = ZC.data.byId.get(id);
    if (!course) return false;
    state.course = id;
    const dialog = cache('course-dialog');
    const cat = cache('cd-cat');
    const title = cache('cd-title');
    const body = cache('cd-body');
    if (cat) cat.textContent = `COURSE #${course.id} · ${course.category}`;
    if (title) title.textContent = course.title;
    if (body) {
      const page = window.ZC.pages && window.ZC.pages.ready ? `./course/${course.id}.html` : null;
      body.innerHTML = `
        <div class="cd-cover"><img src="${core.esc(course.image)}" alt="${core.esc(course.title)} — poster" decoding="async" referrerpolicy="no-referrer"></div>
        <div class="dialog-body">
          <div class="cd-facts">
            <span class="chip">#${course.id}</span>
            <span class="chip">${core.esc(course.category)}</span>
            ${course.creatorName ? `<span class="chip">${core.esc(course.creatorName)}</span>` : ''}
            ${course.rating ? `<span class="chip"><svg class="star" aria-hidden="true"><use href="#i-star"/></svg>${course.rating.score.toFixed(1)} · ${core.count(course.rating.count)} reviews</span>` : ''}
          </div>
          <p>${core.esc(BRAND.fullName)} is a catalogue: it lists this course and connects you with the owner on
            Telegram. Confirm availability, format and access duration there before anything else.</p>
          <div class="cd-actions">
            <a class="ask" href="${core.enquiryFor(course)}" target="_blank" rel="noopener noreferrer">
              <svg aria-hidden="true"><use href="#i-telegram"/></svg><span>Get access on Telegram</span>
            </a>
            <button class="button-ghost" data-copy-current><svg aria-hidden="true"><use href="#i-link"/></svg>Copy link</button>
            <button class="button-ghost" data-save="${course.id}">${iconSpan(ZC.list.has(id))}</button>
          </div>
          ${page ? `<p class="page-link-row"><a href="${page}">Open the standalone page for this course ↗</a></p>` : ''}
        </div>`;
    }
    if (dialog && !dialog.open) dialog.showModal();
    document.title = `${course.title} — ${BRAND.fullName}`;
    writeUrl({ push });
    core.analytics.track('course_open', { id });
    return true;
  }

  const iconSpan = (saved) => `${saved ? 'Saved ✓' : 'Save to list'}`;

  function openCourseFromUrl(attempt = 0) {
    if (state.course == null) return;
    if (openCourse(state.course, { push: false })) return;
    if (attempt < 12) setTimeout(() => openCourseFromUrl(attempt + 1), 250);
    else core.toast(`Course #${state.course} was not found in the archive`);
  }

  function copyCourseLink(id) {
    if (id == null) return;
    const path = window.ZC.pages && window.ZC.pages.ready
      ? `course/${id}.html`
      : `?course=${id}`;
    const url = `${location.origin}${location.pathname}${location.pathname.endsWith('/') ? '' : '/'}${path.replace(/^\.\//, '')}`;
    core.copyText(url).then((ok) => core.toast(ok ? 'Course link copied' : url));
  }

  /* ── Dialogs ───────────────────────────────────────────────────────────── */
  function wireDialogs() {
    document.querySelectorAll('[data-close]').forEach((btn) => {
      btn.addEventListener('click', () => btn.closest('dialog').close());
    });
    document.querySelectorAll('dialog').forEach((dialog) => {
      dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
      dialog.addEventListener('close', () => {
        if (dialog.id === 'course-dialog') {
          state.course = null;
          document.title = `${BRAND.fullName} — Find your next skill`;
          writeUrl();
        }
      });
    });

    const catDialog = cache('category-dialog');
    const openCats = () => {
      renderCategories(); renderCreators();
      if (catDialog && !catDialog.open) catDialog.showModal();
      cache('open-categories')?.setAttribute('aria-expanded', 'true');
    };
    cache('open-categories')?.addEventListener('click', openCats);
    cache('open-categories-2')?.addEventListener('click', openCats);
    catDialog?.addEventListener('close', () => cache('open-categories')?.setAttribute('aria-expanded', 'false'));

    const faq = cache('faq-dialog');
    cache('open-faq')?.addEventListener('click', () => { if (faq && !faq.open) faq.showModal(); });
    cache('collapse-faq')?.addEventListener('click', () => {
      document.querySelectorAll('#faq-dialog details').forEach((d) => { d.open = false; });
    });

    const listDialog = cache('list-dialog');
    const openList = () => { ZC.list.render(); if (listDialog && !listDialog.open) listDialog.showModal(); };
    document.querySelector('.save-trigger')?.addEventListener('click', openList);
    cache('open-list')?.addEventListener('click', openList);
    cache('view-list')?.addEventListener('click', openList);

    cache('reset')?.addEventListener('click', () => {
      state.q = ''; state.cat = ''; state.creator = ''; state.sort = 'relevance';
      if (cache('search')) cache('search').value = '';
      if (cache('sort')) cache('sort').value = 'relevance';
      if (cache('creator-filter')) cache('creator-filter').value = '';
      apply({ scroll: true });
      renderCategories();
      catDialog?.close();
    });
    cache('clear-search')?.addEventListener('click', () => cache('reset')?.click());
  }

  /* ── Grid interactions (delegated) ─────────────────────────────────────── */
  function wireGrid() {
    const grid = cache('grid');

    grid.addEventListener('click', (event) => {
      const saveBtn = event.target.closest('[data-save]');
      if (saveBtn) { ZC.list.toggle(Number(saveBtn.dataset.save)); return; }

      const openLink = event.target.closest('[data-open-course]');
      if (openLink) {
        // Static pages exist → let the browser navigate (real URL, real share).
        if (window.ZC.pages && window.ZC.pages.ready) return;
        event.preventDefault();
        openCourse(Number(openLink.dataset.openCourse));
        return;
      }
      const catBtn = event.target.closest('[data-filter-category]');
      if (catBtn) { setCategory(catBtn.dataset.filterCategory); return; }
      const creatorBtn = event.target.closest('[data-filter-creator]');
      if (creatorBtn) { setCreator(creatorBtn.dataset.filterCreator); return; }
      const copyBtn = event.target.closest('[data-copy-link]');
      if (copyBtn) { copyCourseLink(Number(copyBtn.dataset.copyLink)); return; }
    });

    grid.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const catBtn = event.target.closest('[data-filter-category]');
      if (catBtn) { event.preventDefault(); setCategory(catBtn.dataset.filterCategory); }
    });

    cache('categories')?.addEventListener('click', (event) => {
      const btn = event.target.closest('[data-category]');
      if (btn) setCategory(btn.dataset.category);
    });

    cache('active-filters')?.addEventListener('click', (event) => {
      const btn = event.target.closest('[data-clear-filter]');
      if (!btn) return;
      const key = btn.dataset.clearFilter;
      if (key === 'q') { state.q = ''; if (els['search']) els['search'].value = ''; }
      if (key === 'cat') state.cat = '';
      if (key === 'creator') { state.creator = ''; if (els['creator-filter']) els['creator-filter'].value = ''; }
      apply({ scroll: true });
      renderCategories();
    });

    cache('load-more')?.addEventListener('click', () => {
      ZC.render.showNextRows(4);
      const rows = [...cache('grid').querySelectorAll('.row')];
      (rows[rows.length - 5] || rows[rows.length - 1])?.querySelector('a,button')?.focus();
      apply({ scroll: false });
    });

    cache('course-dialog')?.addEventListener('click', (event) => {
      if (event.target.closest('[data-copy-current]')) { copyCourseLink(state.course); return; }
      const btn = event.target.closest('[data-save]');
      if (btn) { ZC.list.toggle(Number(btn.dataset.save)); btn.textContent = iconSpan(ZC.list.has(Number(btn.dataset.save))); }
    });
  }

  function setCategory(name) {
    state.cat = name || '';
    renderCategories();
    cache('category-dialog')?.close();
    apply({ scroll: true });
    core.analytics.track('filter_category', { cat: name || 'all' });
  }

  function setCreator(name) {
    state.creator = name || '';
    apply({ scroll: true });
    core.analytics.track('filter_creator', { creator: name });
  }

  /* ── Controls ──────────────────────────────────────────────────────────── */
  function wireControls() {
    const search = cache('search');
    const sort = cache('sort');
    if (search) {
      search.value = state.q;
      search.addEventListener('input', core.debounce(() => {
        state.q = search.value.trim();
        apply();
        core.analytics.track('search', { q: state.q, len: state.q.length });
      }, 90));
    }
    cache('search-form')?.addEventListener('submit', (event) => {
      event.preventDefault();
      search?.blur();
      apply({ scroll: true });
    });
    if (sort) {
      sort.value = state.sort;
      sort.addEventListener('change', () => {
        state.sort = sort.value;
        apply({ scroll: true });
        core.analytics.track('sort', { sort: state.sort });
      });
    }
    cache('creator-filter')?.addEventListener('change', (event) => setCreator(event.target.value));

    // Artwork fit toggle — the "resize" control: crop vs. full poster.
    const fitBtn = cache('toggle-fit');
    const syncFit = () => {
      const on = ZC.render.fitArtwork;
      fitBtn?.setAttribute('aria-pressed', String(on));
      const span = fitBtn?.querySelector('span');
      if (span) span.textContent = on ? 'Cropped posters' : 'Fit artwork';
    };
    if (fitBtn) {
      fitBtn.addEventListener('click', () => {
        const next = !ZC.render.fitArtwork;
        ZC.render.setArtworkFit(next);
        core.store.set('void.fit', next);
        syncFit();
        apply({ announce: false });
        core.toast(next ? 'Showing full posters' : 'Showing cropped posters');
        core.analytics.track('artwork_fit', { fit: next });
      });
      syncFit();
    }

    cache('refresh')?.addEventListener('click', async () => {
      core.toast('Checking for new courses…');
      ZC.data.reload();
      const ok = await ZC.data.ready;
      core.toast(ok ? 'Archive refreshed' : 'Could not refresh — check your connection');
    });

    cache('retry-load')?.addEventListener('click', () => {
      cache('error-state').hidden = true;
      cache('grid').setAttribute('aria-busy', 'true');
      ZC.data.reload();
    });

    document.addEventListener('keydown', (event) => {
      const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
      const dialogOpen = !!document.querySelector('dialog[open]');
      if (event.key === '/' && !typing && !dialogOpen) { event.preventDefault(); search?.focus(); search?.select(); }
      else if (event.key === 'Escape' && typing && !dialogOpen) document.activeElement.blur();
      else if (event.key === '?' && !typing && !dialogOpen) { event.preventDefault(); cache('faq-dialog')?.showModal(); }
    });

    window.addEventListener('popstate', () => { readUrl(); syncControls(); apply(); });
    window.addEventListener('scroll', () => {
      cache('site-header')?.classList.toggle('is-condensed', window.scrollY > 60);
    }, { passive: true });
  }

  function syncControls() {
    if (els['search']) els['search'].value = state.q;
    if (els['sort']) els['sort'].value = state.sort;
    if (els['creator-filter']) els['creator-filter'].value = state.creator;
  }

  /* ── Boot ──────────────────────────────────────────────────────────────── */
  function boot() {
    readUrl();
    paintBrand();

    // Order matters: the list renderer repaints save buttons inside the grid.
    ZC.render.init({ grid: cache('grid') });
    ZC.list.init();
    wireDialogs();
    wireGrid();
    wireControls();
    syncControls();
    renderCategories();
    renderCreators();

    ZC.data.on('changed', () => {
      dismissSplash();
      applyDebounced();
      if (!state.paintedOnce || ZC.data.loaded === ZC.data.total) { renderCategories(); state.paintedOnce = true; }
    });
    ZC.data.on('indexed', () => apply({ announce: false }));
    ZC.data.on('state', () => {
      paintMeta(state.lastResults.length ? state.lastResults : ZC.data.all);
      if (ZC.data.state === 'ready' || ZC.data.state === 'partial') {
        cache('grid').removeAttribute('aria-busy');
        apply({ announce: false });
      }
    });
    ZC.data.on('error', (payload) => {
      if (payload.reason === 'shards-failed') { core.toast('Some courses could not load — tap refresh to retry.'); return; }
      cache('grid').removeAttribute('aria-busy');
      cache('error-state').hidden = false;
      cache('grid').innerHTML = '';
      core.analytics.track('load_error', payload);
    });

    ZC.data.boot();
    openCourseFromUrl();
    setTimeout(dismissSplash, 3500);

    // Never leave a visitor on a skeleton: if nothing has rendered in 12 s, offer retry.
    setTimeout(() => {
      if (!ZC.data.loaded) {
        cache('grid').removeAttribute('aria-busy');
        cache('error-state').hidden = false;
      }
    }, 12000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  ZC.app = { state, apply, openCourse, setCategory, setCreator, els };
})(window.ZC);
