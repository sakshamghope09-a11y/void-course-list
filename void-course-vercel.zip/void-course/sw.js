/* sw.js — offline shell for VOID COURSE.
   Only registered from the top-level window over HTTPS (see index.html).
   Strategy:
     • shell (HTML, CSS, JS, fonts)  stale-while-revalidate
     • archive shards               cache-first + background refresh
     • posters on the image CDN     cache-first, trimmed to a sane count
   Bump SHELL_VERSION on every deploy; old caches are dropped on activate. */
const SHELL_VERSION = 'void-v1';
const POSTER_CACHE = 'void-posters-v1';
const MAX_POSTERS = 400;

const SHELL = [
  '/', '/index.html', '/404.html', '/about.html', '/guide.html', '/disclaimer.html',
  '/assets/css/app.css', '/assets/js/boot.js', '/assets/js/brand.js', '/assets/js/core.js',
  '/assets/js/search.js', '/assets/js/data.js', '/assets/js/render.js', '/assets/js/list.js',
  '/assets/js/app.js', '/assets/js/sw-register.js', '/data/meta.js', '/data/ratings.js', '/course/pages.js',
  '/public/mark.png', '/public/favicon.svg', '/public/logo.jpg', '/public/og.jpg',
  '/fonts/cormorant-600.woff2', '/fonts/cormorant-600-italic.woff2',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_VERSION)
      .then((cache) => Promise.allSettled(SHELL.map((url) => cache.add(url))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== SHELL_VERSION && k !== POSTER_CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/** Keep the poster cache from growing without bound. */
async function trimPosters(cache) {
  const keys = await cache.keys();
  if (keys.length <= MAX_POSTERS) return;
  for (const key of keys.slice(0, keys.length - MAX_POSTERS)) await cache.delete(key);
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  const sameOrigin = url.origin === location.origin;
  const isPoster = !sameOrigin && /(^|\.)i\.ibb\.co$|fintaxpro\.in$/.test(url.hostname);
  if (!sameOrigin && !isPoster) return;

  const isShard = sameOrigin && url.pathname.startsWith('/data/');
  const isCoursePage = sameOrigin && url.pathname.startsWith('/course/');

  event.respondWith((async () => {
    /* Posters: cache-first, never revalidate on every card view. */
    if (isPoster) {
      const cache = await caches.open(POSTER_CACHE);
      const hit = await cache.match(request);
      if (hit) return hit;
      try {
        const res = await fetch(request);
        if (res.ok) { cache.put(request, res.clone()); trimPosters(cache); }
        return res;
      } catch {
        return new Response('', { status: 504 });
      }
    }

    const cache = await caches.open(SHELL_VERSION);
    const hit = await cache.match(request, { ignoreSearch: isShard || isCoursePage });

    if (hit) {
      /* Serve immediately, refresh quietly in the background. */
      fetch(request)
        .then((res) => { if (res && res.ok) cache.put(request, res.clone()); })
        .catch(() => {});
      return hit;
    }

    try {
      const res = await fetch(request);
      if (res && res.ok && (isShard || isCoursePage || request.destination === 'document' ||
                            ['style', 'script', 'font', 'image'].includes(request.destination))) {
        cache.put(request, res.clone());
      }
      return res;
    } catch (err) {
      /* Offline: fall back to the shell for navigations, and to the archive
         page for course pages so a deep link never becomes a browser error. */
      if (request.mode === 'navigate') {
        return (await cache.match('/index.html')) || (await cache.match('/')) || Response.error();
      }
      throw err;
    }
  })());
});
