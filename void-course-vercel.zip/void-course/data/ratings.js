/* Owner-supplied aggregate ratings, keyed by course id.
   Only a real score (1–5) and a positive review count render a badge; a course
   with no entry simply shows an "Ask for details" link instead of an empty slot.
   Example:
   window.COURSE_RATINGS = { "142": { "score": 4.6, "count": 218 } };
   This file is deliberately outside /data generation, so `npm run build:data`
   (or a fresh course import) never overwrites it. */
window.COURSE_RATINGS = {};
