# VOID COURSE

A static, framework-free archive of recorded courses — searchable, shareable, and free to
browse. Fork of the reference catalogue, rebuilt for **VOID COURSE** with its own artwork,
its own Telegram handle, and no commerce anywhere in the stack.

```
3,695 courses · 17 categories · 98 creators · 7 data shards · 3,695 static pages
```

---

## Deploy it (Vercel, two minutes)

**Option A — drag and drop**

1. Download `void-course-vercel.zip` (see *Package it* below) and unzip it.
2. Go to <https://vercel.com/new>, choose **Deploy** → *Upload* and drop the folder in.
3. Framework preset: **Other**. Build command: **empty**. Output directory: **empty**.
4. Deploy. Done — it is a set of static files, nothing compiles.

**Option B — Git**

```bash
git init && git add -A && git commit -m "VOID COURSE"
git remote add origin git@github.com:<you>/<repo>.git && git push -u origin main
```

Then *Import Project* on Vercel. Leave every build setting empty.

**After the first deploy:** open `voidx.config.json`, set `siteUrl` to the domain Vercel gave
you (e.g. `https://void-course.vercel.app`), then run `npm run build` and redeploy. That value
is what the canonical tags, the sitemap and the social cards use.

---

## Rebranding — one file

Everything the visitor can read lives in **`voidx.config.json`**: the name, the tagline, the
hero headline, the search placeholder, both Telegram message templates, the handle and the
list cap. Edit it and run:

```bash
npm run brand      # regenerates assets/js/brand.js, public/site.webmanifest, robots.txt
npm run build      # rebuilds the data shards and all 3,695 course pages
```

No component, template or data file hard-codes the brand — if a string appears on the site, it
came from that config. The Telegram handle is validated on build (`5–32 chars, a–z 0–9 _`) so a
typo cannot reach production.

To swap the artwork, replace `assets/brand/logo-source.jpg` with your own lockup and run
`npm run build:logo`. It keys out the background, trims the bands and writes the whole icon set:
`mark.png` (transparent mark), `logo.jpg` (square, for social), `og.jpg` (1200×630 share card),
`apple-touch-icon.png` and `favicon.svg`.

---

## What is in the box

```
index.html              the archive: hero, search, filters, virtualised grid, dialogs
about.html guide.html   static pages (about · how it works · disclaimer)
disclaimer.html 404.html
course/                 3,695 pre-rendered course pages + the A–Z directory
course/pages.js         tells the app that static pages exist (cards link to them)
assets/css/app.css      the whole design system, one file, no preprocessor
assets/js/brand.js      generated from voidx.config.json
assets/js/core.js       brand layer, helpers, storage, toasts, telemetry
assets/js/search.js     inverted index, ranking, fuzzy fallback, category aliases
assets/js/data.js       shard loader + 6-column decoder
assets/js/render.js     windowed poster grid with a measured row height
assets/js/list.js       the saved shortlist (localStorage + Telegram message builder)
assets/js/app.js        state, URL sync, facets, dialogs, keyboard shortcuts
assets/js/boot.js       boots the global object before anything else runs
assets/js/sw-register.js  registers the offline service worker
sw.js                   offline shell (stale-while-revalidate + poster cache)
data/                   meta.js + 7 shards (~333 KiB) — the entire catalogue
fonts/                  subset Cormorant Garamond 600 roman + italic (10.5 KB each)
public/                 logo kit, favicon, manifest, robots.txt
scripts/                build + verification tooling (not needed at runtime)
robots.txt              served from the web root, points at sitemap.xml
sitemap.xml             all 3,700 URLs
vercel.json             headers, caching, clean URLs
```

Deleted on purpose: the original's cart, price badges and checkout copy. There is no
`cart.js`, no `₹` and no "unlock" anywhere in the shipped files — `verify.mjs` fails the build
if one comes back.

---

## How it works

**The grid is virtualised.** Rows are absolutely positioned inside `#grid`; only the visible
rows (plus two of overscan) are in the DOM. Scrolling the whole 3,695-course catalogue keeps
under ~80 cards and ~2,500 nodes in memory instead of tens of thousands.

**Cards cannot reflow.** Each cover is a fixed height (`--cover-h`), every title is clamped to
two lines, and the row height is measured once per column count from a real card in a hidden
probe. Posters arrive in every aspect ratio; they are cropped with `object-fit: cover`, or shown
whole with **Fit artwork** (`#grid[data-fit="true"]`). The grid never jumps.

**Search runs on the device.** `search.js` builds an inverted index over the shards with
AND semantics, exact-number pinning (`#142`), quoted phrases, category aliases (`nifty`,
`dsa`, `gst`) and a one-edit fuzzy fallback. Filters are written into the URL, so any view is
a link.

**Every course has a page.** `scripts/build-pages.mjs` pre-renders `course/<id>.html` with a
title, description, canonical, Open Graph image, `Course` JSON-LD and four same-category
neighbours. No JavaScript is required to read it, and `sitemap.xml` lists all 3,700 URLs.

**One Telegram handle.** Every CTA, every enquiry and the whole saved-list message are built
from `voidx.config.json` — `@voidx_exee` today. Messages are assembled inside a 3,500-character
budget so the link is never truncated.

**Nothing to buy.** Courses are not sold here. There is no price, no cart, no checkout and no
payment code in the repository; the delivery promise is simply *get access on Telegram*.

---

## Commands

| Command | What it does |
| --- | --- |
| `npm run build` | brand → data shards → course pages. Run after editing the config or source data. |
| `npm run verify` | 60+ assertions against the files and a live browser (behaviour, geometry, a11y, no-pricing, handle). |
| `npm run check` | `build` then `verify` — the gate to run before deploying. |
| `npm run serve` | Serves the folder on <http://127.0.0.1:8080> the way Vercel would. |
| `npm run build:logo` | Rebuilds the icon set from `assets/brand/logo-source.jpg`. |
| `npm run build:fonts` | Re-subsets the display face (needs `fonttools` + `brotli`). |
| `npm run bench <url> <label>` | Throttled mobile measurement: FCP, first card, transfer, DOM, heap → `deliverables/bench-<label>.json`. |
| `npm run zip` | Produces `void-course-vercel.zip`, ready to upload. |

`verify.mjs` needs Chrome:

```bash
bash scripts/get-chrome.sh              # fetches chrome-headless-shell into ~/.tools
export LD_LIBRARY_PATH=/home/user/.tools/libs/root/usr/lib/x86_64-linux-gnu:/home/user/.tools/libs/root/lib/x86_64-linux-gnu
npm run check
```

---

## Editing the catalogue

`src/courses.source.js` is the raw export. `scripts/build-data.mjs` cleans it (dedupes ids,
trims titles, resolves creators, indexes categories) and writes `data/meta.js` plus seven
shards; the price column from the original export is dropped and the dropped values are
recorded in `data/build-report.json` for the record. After editing, re-run `npm run build` —
course pages and the sitemap are regenerated from the same rows, so they cannot drift.

## Notes

- Course titles and posters belong to their respective owners; this project indexes them.
- `verify.mjs` writes its results to `deliverables/verify.json`.
- The service worker only registers over HTTPS on a real domain, never on `file://`.
