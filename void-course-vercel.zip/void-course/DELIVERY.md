# VOID COURSE — your deployable site

Everything in this folder is the finished site. **`void-course-vercel.zip` is the file you upload.**

---

## 1 · Deploy (about two minutes)

1. Download **`void-course-vercel.zip`** from this folder and unzip it. You get `void-course/`.
2. Open <https://vercel.com/new> → **Deploy** → *Upload* (or drag the `void-course` folder in).
3. Framework preset **Other**. Build command **empty**. Output directory **empty**.
4. Deploy. Your archive is live.

Then, once Vercel gives you a domain:

5. Open `voidx.config.json`, set `"siteUrl"` to that domain, run `npm run build`, and re-upload.
   That value feeds the canonical tags, `sitemap.xml` and the share cards.

> Prefer Git? `git init && git add -A && git commit -m "VOID COURSE"`, push, then *Import Project*
> on Vercel. Same settings, nothing to build.

`void-course-project.zip` is the same site **plus** the tooling and the raw course export
(`scripts/`, `src/`), in case you want to regenerate the data later. You do not need it to deploy.

---

## 2 · Your branding is already in

| | |
| --- | --- |
| Name | **VOID COURSE** — *Learn • Grow • Achieve*, since 2021 |
| Telegram | **@voidx_exee** — on every button, every enquiry, the saved-list message, the footer |
| Logo | your artwork, keyed and cropped into `mark.png`, `logo.jpg`, `og.jpg`, `apple-touch-icon.png`, `favicon.svg` |
| Theme | near-black `#0a0a0c` with warm ivory type, engraved serif headings (Cormorant Garamond 600) |
| Pricing | **none** — no prices, no cart, no checkout, no "unlock". The archive is presented as free to browse |

To change any word, name or handle later: edit **`voidx.config.json`** and run `npm run brand`
(or `npm run build`). Nothing else in the codebase hard-codes the brand.

---

## 3 · What the site does

- **3,695 courses · 17 categories · 98 creators**, in 7 data shards — 333 KB total, gzipped on the wire.
- **Search** that handles `dsa`, `#142`, `142`, `sigma 12`, `"delta batch"`, `pyton` (typos) and
  everyday words for categories (`nifty`, `gst`, `chatgpt`).
- **Facets** — category drawer, creator filter, six sort orders. Every filter is written into the URL,
  so any view is a shareable link.
- **Saved shortlist** (up to 15) that builds one pre-written Telegram message and copies as plain text.
- **Every course has its own page** — `course/<id>.html`, 3,695 of them, pre-rendered, no JavaScript
  needed to read them, with `Course` JSON-LD and a canonical URL. Plus an A–Z directory at `course/`.
- **Offline** — a service worker keeps the archive working with no connection once visited.
- Reference-site functions all kept: FAQ, category drawer, loading state, toasts, sticky bar,
  keyboard shortcuts (`/` search, `?` FAQ, `Esc` back).

## 4 · Card sizing (your "resize" note)

Every cover is a locked 208 px (200 px on phones), every title is clamped to exactly two lines,
every byline row is a fixed 24 px, and the grid row height is measured once from a real card.
Posters arrive in wildly different shapes from the image host; they are cropped to fit, and
**Fit artwork** in the toolbar switches to showing them whole (`contain`) — your choice is remembered.
The grid never jumps or goes ragged, at any window width.

## 5 · Verified twice

`npm run verify` runs 76 assertions against the files **and** a live headless browser.

| Run | Target | Result |
| --- | --- | --- |
| Check 1 | the working tree | **76/76 — clean** |
| Check 2 | the **unzipped deployment** on a fresh server | **76/76 — clean** |

It covers: data integrity (3,695 rows, no dupes, no missing posters), the no-pricing guarantee
(currency, cart and checkout artefacts scanned across every shipped file), the single Telegram handle,
search semantics, facets, sorting, card geometry, the saved list + message budget, deep links,
static pages, DOM bounds while scrolling the whole catalogue, WCAG target sizes, console cleanliness,
and the degraded-network retry state. Results are in `deliverables/verify.json`; screenshots of every
screen (desktop, tablet, phone) are in `deliverables/shots/`.

Measured on a throttled phone profile (Slow-4G, 4× CPU, 390×844): first paint **0.84 s**, usable grid
**~2.0 s**, full load **3.99 s**, 526 DOM nodes at load, 9.5 MB heap — for 3,695 courses. Most of the
transfer is poster images from the image host, which serves one fixed size per image
(2.9 MB of the 3.4 MB total); posters below the fold are lazy-loaded.

---

## 6 · Housekeeping

- `README.md` — full technical documentation (architecture, commands, how to edit the catalogue).
- `robots.txt`, `sitemap.xml` (3,700 URLs), `public/site.webmanifest` — search-engine and install metadata.
- `vercel.json` — security headers (strict CSP, no inline script or style anywhere) + caching rules.
- Delete `course/` if you ever want a smaller upload — cards then open the in-page course view
  instead of a page, and `sitemap.xml` should be regenerated.
- Course titles and posters belong to their respective owners; this site indexes them and says so
  on every course page, in the footer, and on the disclaimer page.
